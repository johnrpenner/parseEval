// Kurt Moerman's Arneodo Attractor on Simulated Oscilloscope
// 
// ── arneodo.bas ───────────────────────────────────────────────────
// Arneodo attractor on simulated analog oscilloscope
// Plots Z as function of X with CRT phosphor persistence effect
// dx/dt = y
// dy/dt = z
// dz/dt = a*x - c*x^3 - b*y - z

// ── Attractor parameters ──────────────────────────────────────────
var aa   : Float = 5.5
var bb   : Float = 3.5
var cc   : Float = 1.0
var x0   : Float = 1.0
var y0   : Float = 1.0
var z0   : Float = 0.0
var dt   : Float = 0.005
var nn   : Int   = 150

// ── State variables ───────────────────────────────────────────────
var xx   : Float = 1.0
var yy   : Float = 1.0
var zz   : Float = 0.0
var xnew : Float = 0.0
var ynew : Float = 0.0
var znew : Float = 0.0

// ── Screen mapping ────────────────────────────────────────────────
// Canvas is 1260 x 1000, centre at 630, 500
// X range of attractor: approx -4.5 to 4.5  → scale 120 px per unit
// Z range of attractor: approx -14 to 14    → scale 35 px per unit
var cx     : Float = 630.0
var cy     : Float = 500.0
var xscale : Float = 120.0
var zscale : Float = 35.0

// ── Working variables ─────────────────────────────────────────────
var sx     : Float = 0.0
var sy     : Float = 0.0
var sxnew  : Float = 0.0
var synew  : Float = 0.0
var frame  : Float = 0.0
var ii     : Int   = 0

// ── Ring buffer for fade pass — store last 200 line segments ──────
// Each segment: x1, y1, x2, y2
var bufSize : Int = 200
var bx1[200] : Float
var by1[200] : Float
var bx2[200] : Float
var by2[200] : Float
var bufHead  : Int = 0
var fadeIdx  : Int = 0

// ── Draw grid once at start ───────────────────────────────────────
var gi     : Int   = 0
var gx     : Float = 0.0
var gy     : Float = 0.0
var gcol   : Float = 0.3

CLS
PEN 2.0

// Outer border
LINE(30.0, 30.0, 1230.0, 30.0, gcol, gcol, gcol, 1.0)
LINE(1230.0, 30.0, 1230.0, 970.0, gcol, gcol, gcol, 1.0)
LINE(1230.0, 970.0, 30.0, 970.0, gcol, gcol, gcol, 1.0)
LINE(30.0, 970.0, 30.0, 30.0, gcol, gcol, gcol, 1.0)

// Centre crosshair
LINE(30.0, 500.0, 1230.0, 500.0, gcol, gcol, gcol, 1.0)
LINE(630.0, 30.0, 630.0, 970.0, gcol, gcol, gcol, 1.0)

// Vertical grid lines (9 divisions)
gi = 1
while (gi < 10) {
    gx = 30.0 + gi * 120.0
    LINE(gx, 30.0, gx, 970.0, gcol, gcol, gcol, 0.5)
    gi = gi + 1
}

// Horizontal grid lines (7 divisions)
gi = 1
while (gi < 8) {
    gy = 30.0 + gi * 120.0
    LINE(30.0, gy, 1230.0, gy, gcol, gcol, gcol, 0.5)
    gi = gi + 1
}

LOCATE 1, 1
print "Arneodo Attractor  —  X vs Z"
LOCATE 2, 1
print "a=5.5  b=3.5  c=1.0"

// ── Initialise buffer to centre point ────────────────────────────
ii = 0
while (ii < 200) {
    bx1[ii] = cx
    by1[ii] = cy
    bx2[ii] = cx
    by2[ii] = cy
    ii = ii + 1
}

// ── Main animation loop ───────────────────────────────────────────
//BUFFER:1

FOR frame = 0 TO 99999 STEP 1

    // Draw pass — nn Euler steps per frame
    PEN 2.0
    ii = 0
    while (ii < nn) {
        xnew = xx + dt * yy
        ynew = yy + dt * zz
        znew = zz + dt * (aa * xx - cc * xx * xx * xx - bb * yy - zz)

        sx    = cx + xx   * xscale
        sy    = cy - zz   * zscale
        sxnew = cx + xnew * xscale
        synew = cy - znew * zscale

        // Plot bright green point with low alpha — accumulates on revisit
        //LINE(sx, sy, sxnew, synew, 0.08, 1.0, 0.08, 0.05)
        LINE(sx, sy, sxnew, synew, 0.08, 1.0, 0.08, 0.50)
		
        // Store segment in ring buffer
        bx1[bufHead] = sx
        by1[bufHead] = sy
        bx2[bufHead] = sxnew
        by2[bufHead] = synew
        bufHead = bufHead + 1
        if bufHead >= bufSize then bufHead = 0

        xx = xnew
        yy = ynew
        zz = znew
        ii = ii + 1
    }

    // Fade pass — redraw old segments in translucent black
    PEN 2.5
    fadeIdx = 0
    while (fadeIdx < bufSize) {
        //LINE(bx1[fadeIdx], by1[fadeIdx], bx2[fadeIdx], by2[fadeIdx], 0.0, 0.0, 0.0, 0.18)
        LINE(bx1[fadeIdx], by1[fadeIdx], bx2[fadeIdx], by2[fadeIdx], 0.0, 0.0, 0.0, 0.65)
        fadeIdx = fadeIdx + 1
    }

    //BUFFER

NEXT frame

//BUFFER:0
END
