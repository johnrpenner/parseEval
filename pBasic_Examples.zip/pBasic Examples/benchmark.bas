var S : Float = 0.0
var R : Float = 0.0
var A : Float = 0.0
for N = 1 to 100
	A = N
	for I = 1 to 10
		A = SQR(A)
		R = R + RND(1)
	next I

	for I = 1 to 10
		A = A^2
		R = R + RND(1)
	next I

	S = S + A
next N
print abs(1010-S/5)
print abs(1000-R)

