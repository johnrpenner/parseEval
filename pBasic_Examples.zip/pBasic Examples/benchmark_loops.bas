// benchmark_loops.bas
// QuickBasic 4.5 style performance test converted for pBasic
// Uses TIME (string) for start/end display - no TIMER command

CLS
print "pBasic Performance Test (empty FOR loop)"
print "========================================"

var L : Int = 100000          // change this to test different sizes
var i : Int = 0

print "Time Start"
print TIME

for i = 1 to L
    // empty loop - just counting cycles
next i

print "Time End"
print TIME

print ""
print "Loops performed = "; 
print L
print ""
print "Press any key to exit..."

var k$ : String = ""
while (k$ == "") {
    k$ = INKEY$
}
end
