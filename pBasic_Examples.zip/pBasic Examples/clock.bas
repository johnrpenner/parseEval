print "pBasic Digital Clock"
TIMER 1.0 showClock
TIMERON
input "type Enter to quit "; A$
print "Thank you ";
print A$
end
func showClock() {
locate 12,12
print time
return 0
}
