// Milestone 38: DIST() Performance Test
// Compares native DIST() vs interpreted pDist() over 10,000 iterations
// Uses a loop counter and TIME to measure wall-clock seconds.
// Also verifies both functions return identical results.

print "============================================"
print "  Milestone 38 — DIST() Performance Test"
print "============================================"
print ""

// ─────────────────────────────────────────────
// Correctness check first
// ─────────────────────────────────────────────
print "--- Correctness Check ---"
var cx1 : Float = 0.0
var cy1 : Float = 0.0
var cx2 : Float = 400.0
var cy2 : Float = 500.0

var nativeResult  : Float = DIST(cx1, cy1, cx2, cy2)
var interpResult  : Float = pDist(cx1, cy1, cx2, cy2)

print "DIST()  = " + STR$(nativeResult)
print "pDist() = " + STR$(interpResult)

var diff : Float = ABS(nativeResult - interpResult)
if (diff < 0.001) {
    print "PASS: results match within 0.001"
}
if (diff >= 0.001) {
    print "FAIL: results differ by " + STR$(diff)
}
print ""

// ─────────────────────────────────────────────
// Performance test — native DIST()
// ─────────────────────────────────────────────
print "--- Native DIST() x 100,000 ---"
var startTime$ : String = TIME
print "Start: " + startTime$

var x1 : Float = 0.0
var y1 : Float = 0.0
var x2 : Float = 0.0
var y2 : Float = 0.0
var d  : Float = 0.0
var accum : Float = 0.0
var i  : Int = 0

for i = 0 to 99999
    x1 = i * 0.5
    y1 = i * 0.3
    x2 = i * 1.2
    y2 = i * 0.7
    d = DIST(x1, y1, x2, y2)
    accum = accum + d
next i

var endTime$ : String = TIME
print "End:   " + endTime$
print "Accum: " + STR$(accum)
print ""

// ─────────────────────────────────────────────
// Performance test — interpreted pDist()
// ─────────────────────────────────────────────
print "--- Interpreted pDist() x 100,000 ---"
var startTime2$ : String = TIME
print "Start: " + startTime2$

var x1b : Float = 0.0
var y1b : Float = 0.0
var x2b : Float = 0.0
var y2b : Float = 0.0
var db  : Float = 0.0
var accumB : Float = 0.0
var j  : Int = 0

for j = 0 to 99999
    x1b = j * 0.5
    y1b = j * 0.3
    x2b = j * 1.2
    y2b = j * 0.7
    db = pDist(x1b, y1b, x2b, y2b)
    accumB = accumB + db
next j

var endTime2$ : String = TIME
print "End:   " + endTime2$
print "Accum: " + STR$(accumB)
print ""

// ─────────────────────────────────────────────
// Final accumulator comparison
// ─────────────────────────────────────────────
print "--- Accumulator Comparison ---"
var accumDiff : Float = ABS(accum - accumB)
print "DIST()  accum = " + STR$(accum)
print "pDist() accum = " + STR$(accumB)
if (accumDiff < 1.0) {
    print "PASS: accumulators match within 1.0"
}
if (accumDiff >= 1.0) {
    print "FAIL: accumulators differ by " + STR$(accumDiff)
}
print ""

print "============================================"
print "  Performance Test Complete"
print "============================================"
end

// ─────────────────────────────────────────────
// pDist() — interpreted equivalent of DIST()
// Uses SQRT(dx*dx + dy*dy) — no hypot()
// ─────────────────────────────────────────────
func pDist(x1, y1, x2, y2) {
    var dx : Float = x2 - x1
    var dy : Float = y2 - y1
    return SQRT(dx * dx + dy * dy)
}
