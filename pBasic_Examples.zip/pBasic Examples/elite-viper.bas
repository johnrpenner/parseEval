// viper3D.bas — wireframe ship, dual-axis rotation ────────────────
// Up/Down arrows: add X-axis spin
// Left/Right arrows: add Y-axis spin
// Rotations accumulate and combine freely
// ESC or CTRL-C to quit

// ── Model vertices ───────────────────────────────────────────────
var vx[15] : Float
var vy[15] : Float
var vz[15] : Float

vx[0] = 0
vy[0] = 0
vz[0] = 72
vx[1] = 0
vy[1] = 16
vz[1] = 24
vx[2] = 0
vy[2] = -16
vz[2] = 24
vx[3] = 48
vy[3] = 0
vz[3] = -24
vx[4] = -48
vy[4] = 0
vz[4] = -24
vx[5] = 24
vy[5] = -16
vz[5] = -24
vx[6] = -24
vy[6] = -16
vz[6] = -24
vx[7] = 24
vy[7] = 16
vz[7] = -24
vx[8] = -24
vy[8] = 16
vz[8] = -24
vx[9] = -32
vy[9] = 0
vz[9] = -24
vx[10] = 32
vy[10] = 0
vz[10] = -24
vx[11] = 8
vy[11] = 8
vz[11] = -24
vx[12] = -8
vy[12] = 8
vz[12] = -24
vx[13] = -8
vy[13] = -8
vz[13] = -24
vx[14] = 8
vy[14] = -8
vz[14] = -24

// ── Edges ─────────────────────────────────────────────────────────
var edgeStart[20] : Int
var edgeEnd[20] : Int

edgeStart[0] = 0
edgeEnd[0] = 3
edgeStart[1] = 0
edgeEnd[1] = 1
edgeStart[2] = 0
edgeEnd[2] = 2
edgeStart[3] = 0
edgeEnd[3] = 4
edgeStart[4] = 1
edgeEnd[4] = 7
edgeStart[5] = 1
edgeEnd[5] = 8
edgeStart[6] = 2
edgeEnd[6] = 5
edgeStart[7] = 2
edgeEnd[7] = 6
edgeStart[8] = 7
edgeEnd[8] = 8
edgeStart[9] = 5
edgeEnd[9] = 6
edgeStart[10] = 4
edgeEnd[10] = 8
edgeStart[11] = 4
edgeEnd[11] = 6
edgeStart[12] = 3
edgeEnd[12] = 7
edgeStart[13] = 3
edgeEnd[13] = 5
edgeStart[14] = 9
edgeEnd[14] = 12
edgeStart[15] = 9
edgeEnd[15] = 13
edgeStart[16] = 10
edgeEnd[16] = 11
edgeStart[17] = 10
edgeEnd[17] = 14
edgeStart[18] = 11
edgeEnd[18] = 14
edgeStart[19] = 12
edgeEnd[19] = 13

// ── Camera angles ─────────────────────────────────────────────────
var rotY : Float = 0.0
var rotX : Float = -0.3

// ── Spin speeds (radians per frame, accumulate freely) ────────────
var spinY : Float = 0.03
var spinX : Float = 0.0

// ── Projection constants ──────────────────────────────────────────
var zoom : Float = 5.0
var dist : Float = 220.0
var cx   : Float = 630.0
var cy   : Float = 500.0

// ── Per-frame working variables ───────────────────────────────────
var cosY : Float = 0.0
var sinY : Float = 0.0
var cosX : Float = 0.0
var sinX : Float = 0.0
var prx  : Float = 0.0
var prz  : Float = 0.0
var pry  : Float = 0.0
var prz2 : Float = 0.0
var pw   : Float = 0.0
var sx1  : Float = 0.0
var sy1  : Float = 0.0
var sx2  : Float = 0.0
var sy2  : Float = 0.0
var ai   : Int   = 0
var bi   : Int   = 0
var ei   : Int   = 0
var vi   : Int   = 0
var frame : Float = 0.0
var k$   : String = ""

// ── Projected screen coords for all 15 vertices ───────────────────
var psx[15] : Float
var psy[15] : Float

CLS
PEN 1.8
BUFFER:1

FOR frame = 0 TO 9999 STEP 1

    k$ = INKEY$
    if k$ == "ESC" then frame = 10000
    if k$ == "^U" then spinX = spinX - 0.01
    if k$ == "^D" then spinX = spinX + 0.01
    if k$ == "^L" then spinY = spinY - 0.01
    if k$ == "^R" then spinY = spinY + 0.01

    // Round to 4 decimal places to kill floating point drift
    spinX = INT(spinX * 10000.0 + 0.5) / 10000.0
    spinY = INT(spinY * 10000.0 + 0.5) / 10000.0

    // Clamp runaway values
    if spinY > 100.0 then spinY = 0.0
    if spinY < -100.0 then spinY = 0.0
    if spinX > 100.0 then spinX = 0.0
    if spinX < -100.0 then spinX = 0.0

    LOCATE 1, 60
    print "SpinX: ";
    print spinX;
    print "    "
    LOCATE 2, 60
    print "SpinY: ";
    print spinY;
    print "    "

    cosY = COS(rotY)
    sinY = SIN(rotY)
    cosX = COS(rotX)
    sinX = SIN(rotX)

    vi = 0
    while (vi < 15) {
        prx  = vx[vi] * cosY - vz[vi] * sinY
        prz  = vx[vi] * sinY + vz[vi] * cosY
        pry  = vy[vi] * cosX - prz * sinX
        prz2 = vy[vi] * sinX + prz * cosX
        pw   = dist / (dist + prz2 + 60.0)
        psx[vi] = cx + prx * zoom * pw
        psy[vi] = cy - pry * zoom * pw
        vi = vi + 1
    }

    CLR
	
    ei = 0
    while (ei < 20) {
        ai  = edgeStart[ei]
        bi  = edgeEnd[ei]
        sx1 = psx[ai]
        sy1 = psy[ai]
        sx2 = psx[bi]
        sy2 = psy[bi]
        LINE(sx1, sy1, sx2, sy2, 0.9, 0.85, 0.5, 1.0)
        ei = ei + 1
    }

    PEN 4.0
    vi = 0
    while (vi < 15) {
        POINT(psx[vi], psy[vi], 0.4, 0.85, 1.0, 1.0)
        vi = vi + 1
    }
    PEN 1.8

    BUFFER

    rotY = rotY + spinY
    rotX = rotX + spinX

NEXT frame

BUFFER:0
END
