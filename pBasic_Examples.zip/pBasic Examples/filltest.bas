// filltest.bas • milestone 35 FILL() command

cls

// dark green background
TEXT(1, 0, 0, 1)
fill(0, 0.3, 0, 1)
for z = 1 to 10
print "red on green  ";
next z
print

// dark red background
FILL(0.5, 0, 0, 1)
for z = 1 to 10
print "red on red  ";
next z
print

// black background fill
fill(0, 0, 0, 1)
for z = 1 to 10
print "red on black  ";
next z
print

// transparent background fill (default)
fill(0,0,0,0)
for z = 1 to 10
print "red in space  ";
next z
print


//-- restore transparent default ----------------

// dark green background
TEXT(0, 0.91, 0.23, 1)
fill(0, 0.3, 0, 1)
for z = 1 to 10
print "hello on green  ";
next z
print

// dark red background
FILL(0.5, 0, 0, 1)
for z = 1 to 10
print "green on red  ";
next z
print

// black background fill
TEXT(0,0,1,1)
fill(0, 0, 0, 1)
for z = 1 to 10
print "blue on black  ";
next z
print

// restore transparent default
fill(0,0,0,0)
for z = 1 to 10
print "blue in space  ";
next z
print

// dark green background
TEXT(0, 0.91, 0.23, 1)
fill(0,0,0,0)
for z = 1 to 10
print "green in space  ";
next z
print ""

end
