var n = 0
for z = 1 to 10
	n = myFunc(z)
	print "for ";
	print z;
	print " myFunc = ";
	print n
next z

func myFunc(A) {
	var k = 0
	let k = A * A
	return k
}
