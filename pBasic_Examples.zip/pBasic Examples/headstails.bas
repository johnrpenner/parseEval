// now we can add comments to the top of this file. 

var R : Float = 0.0
for N = 1 to 10
	R = rnd(1)
	if R > 0.5 then print "Heads"
	if R <= 0.5 then print "Tails"
next N

// hello world SPHINX OF BLACK QUARTZ JUDGE MY VOW
// hello world sphinx of black quartz judge my vow 



