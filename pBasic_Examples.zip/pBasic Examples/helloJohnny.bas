// helloJohnny.bas
// notes go here

var a$ = "hello "
var b$ = "johnny "

for n = 1 to 100
print a$ + b$ + "  ";
next n
