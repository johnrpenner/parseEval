// inkeytest.bas -> tests INKEY$
var running : Bool = 1
var k$ : String = ""
locate 10,35
print "INKEY TEST";
while (running == 1) {
    k$ = INKEY$
    locate 11, 35
    if k$ == "^U" then print "Up Arrow    "
    if k$ == "^D" then print "Down Arrow  "
    if k$ == "^L" then print "Left Arrow  "
    if k$ == "^R" then print "Right Arrow "
    if k$ == "RET" then print "Return key "
    if k$ == "DEL" then print "Delete key "
    if k$ == " " then print   "Space key  "
    if k$ == "ESC" then running = 0
}
print "Goodbye!   "
