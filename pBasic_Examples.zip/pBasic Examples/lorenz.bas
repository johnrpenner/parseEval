// lorenz.bas
// Lorenz Attractor - converted to pBasic
// pBASIC Demo by John Roland Penner ©2026

CLS
PEN 4.0
print "Lorenz Attractor"
print "ESC to quit"

var running : Int = 1
var k$      : String = ""

var x : Float = 1.0
var y : Float = 1.0
var z : Float = 16.0

var dt : Float = 0.008     // time step
var rr : Float = 0.0
var gg : Float = 0.0
var bb : Float = 0.0

while (running == 1) {
    k$ = INKEY$

    if (k$ == "ESC") {
        running = 0
    }

    BUFFER:1
    CLR

    var i : Int = 0
    for i = 0 to 2800
        // Lorenz equations
        var dx : Float = 10.0 * (y - x)
        var dy : Float = x * (28.0 - z) - y
        var dz : Float = x * y - (8.0 / 3.0) * z

        x = x + dx * dt
        y = y + dy * dt
        z = z + dz * dt

        // Project to screen
        var sx : Float = 630.0 + x * 18.0
        var sy : Float = 520.0 - (y + z * 0.4) * 9.5

        // Colour based on height (z)
        var hue : Float = 30.0 + z * 3.0
        setHSBColor(hue)

        POINT(sx, sy, rr, gg, bb, 0.95)
    next i

    BUFFER
}

print ""
print "Goodbye!"
end

// ── Simple HSB to RGB (hue 0-360) ───────────────────────────────────────────
func setHSBColor(h) {
    rr = 0.0
    gg = 0.0
    bb = 0.0

    if (h < 120.0) {
        rr = 1.0 - h/120.0
        gg = h/120.0
        bb = 0.0
    }

    if (h >= 120.0) {
        rr = 0.0
        gg = 1.0 - (h-120.0)/120.0
        bb = (h-120.0)/120.0
    }

    if (h >= 240.0) {
        rr = (h-240.0)/120.0
        gg = 0.0
        bb = 1.0 - (h-240.0)/120.0
    }

    return 0
}
