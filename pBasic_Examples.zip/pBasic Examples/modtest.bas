// modtest.bas Milestone 37: % MOD operator test
// Tests integer mod, float mod, zero divisor, and mod in expressions

var a : Int = 10
var b : Int = 3
var r : Int = 0

r = a % b
print "10 % 3 = " + STR$(r)         // expect: 1

r = 10 % 5
print "10 % 5 = " + STR$(r)         // expect: 0

r = 7 % 7
print "7 % 7 = " + STR$(r)          // expect: 0

r = 1 % 7
print "1 % 7 = " + STR$(r)          // expect: 1

var c : Float = 0.0
c = 10.5 % 3.0
print "10.5 % 3.0 = " + STR$(c)     // expect: 1.5

c = -7.0 % 3.0
print "-7.0 % 3.0 = " + STR$(c)     // expect: -1.0

// MOD in a FOR loop — print even numbers 0-10
print "Even numbers 0-10:"
var n : Int = 0
for n = 0 to 10
    if n % 2 == 0 then print n;
next n
print ""

// MOD to wrap a value — clock hand cycling 0..11
print "Clock wrap 0-11:"
var h : Int = 0
for h = 0 to 14
    var w : Int = h % 12
    print w;
next h
print ""

