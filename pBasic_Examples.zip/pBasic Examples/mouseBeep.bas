// mouseBeep.bas — Milestone 36 validation
// Move mouse over canvas, click to plot a point at cursor position

print "Move mouse and click to plot"
print "Press ESC to exit"

// Load sounds once at startup
PLAY(1, 1.0, "pBasic/Laser.wav")
PLAY(2, 0.8, "pBasic/Pickup.wav")
PLAY(3, 0.8, "pBasic/Sproing.wav")

TIMER 0.05 mouseLoop
TIMERON

CLS
PEN 5.0

var mx : Float = MOUSEAT(X)
var my : Float = MOUSEAT(Y)
var mb : Float = MOUSEAT(B)
var rSnd : Int = 1
var running : Int = 1

while (running == 1) {
}

print ""
end

func mouseLoop() {
	mx = MOUSEAT(X)
	my = MOUSEAT(Y)
	mb = MOUSEAT(B)
	rSnd = INT(RND(0) * 3 + 1)
	locate 1, 50
	print "mx: " + str$(mx) + "  my: " + str$(my) + "    "
	
	if (mb > 0.0) then POINT(mx, my, 1, 0, 0, 1)
	if (mb > 1.0) then CLR
	if (mb > 1.0) then PLAY(rSnd)
	
	var k$ : String = INKEY$
	if k$ == "ESC" then running = 0
	return 0
}
