// mouseChord.bas — Milestone 33 validation
// Move mouse over canvas, click to play a chord at cursor position

print "Move mouse and click to play"
print "Press ESC to exit"

// Load sounds once at startup
//PLAY(1, 1.0, "pBasic/Laser.wav")
//PLAY(2, 0.8, "pBasic/Pickup.wav")
//PLAY(3, 0.8, "pBasic/Sproing.wav")

TIMER 0.125 mouseLoop
TIMERON

CLS
PEN 7.0

var mx : Float = MOUSEAT(X)
var my : Float = MOUSEAT(Y)
var mb : Float = MOUSEAT(B)
var rSnd : Int = 1
var isPlaying : Bool = 0
var numTicks : Int = 0
var running : Int = 1
var mInterval : Int = 3

// draw keyboard
buffer
line(100, 250, 1200, 250, 0.2, 0.2, 0.2, 1.0)
for n = 1 to 12.6
	line(n*100, 250, n*100, 350, 0.2, 0.2, 0.2, 1.0)
next n
buffer

while (running == 1) {
}

print ""
end

func mouseLoop() {
	mx = MOUSEAT(X)
	my = MOUSEAT(Y)
	mb = MOUSEAT(B)
	rSnd = INT(mx/100) + 60
	locate 1, 50
	print "mx: " + str$(mx) + "  my: " + str$(my) + "    ";
	locate 2, 50
	print "midi: " + str$(rSnd) + " + " + str$(rSnd + mInterval) + " | " + str$(mInterval) + "  ";
	
	if (mb > 1.0) then CLR
	if (mb > 0.0) then POINT(mx, my, 1, 0, 0, 1)
	
	// fire all sounds simultaneously
	//if (mb > 0.0) then SOUND(rSnd, 0.24, 0.8)
	//if (mb > 0.0) then SOUND(rSnd+3, 0.24, 0.8)
	//if (mb > 0.0) then SOUND(rSnd+7, 0.24, 0.8)
	
	// fire sounds only if isPlaying is false
	if (mb > 0.0) && (isPlaying == 0) then bleep()
	
	// sounds play for 0.25 and tick are 0.125 --> so 2 ticks
	numTicks = numTicks + 1
	if numTicks > 2 then resetTicks()
	
	var k$ : String = INKEY$
	if k$ == "ESC" then running = 0
	if k$ == "^U" then mInterval = mInterval + 1
	if k$ == "^D" then mInterval = mInterval - 1
	
	return 0
}

func bleep() {
	isPlaying = 1
	SOUND(rSnd, 0.24, 0.8)
	SOUND(rSnd+mInterval, 0.24, 0.8)
	return 0
}

func resetTicks() {
	numTicks = 0
	isPlaying = 0
	return 0
}
