// multilineIFtest.bas

print "─────────────────────────────────────────────"
print "  Milestone 39 — Multi-Line IF { } Tests"
print "─────────────────────────────────────────────"
print ""

print "--- Test 1: Basic IF true ---"
var a : Int = 10

IF (a > 5 ) then print "hello "



if (a > 5) {
    print "PASS: a > 5"
    print "PASS: second line executed"
}

print "PASS: after IF block"
print ""


print "============================================"
print "  Milestone 39 Tests Complete"
print "============================================"
end

