// multilineIFtest.bas
// Milestone 39: Multi-Line IF { } Stress Test
// Tests: multi-line IF, nested IF, IF inside WHILE,
//        WHILE inside IF, single-line IF THEN, all combined.

print "============================================"
print "  Milestone 39 — Multi-Line IF { } Tests"
print "============================================"
print ""

// ─────────────────────────────────────────────
// Test 1: Basic multi-line IF — condition true
// ─────────────────────────────────────────────
print "--- Test 1: Basic IF true ---"
var a : Int = 10

if (a > 5) then print "PASS: a > 5"
if (a > 5) then print "PASS: second line executed"

if (a > 5) {
    print "PASS: a > 5"
    print "PASS: second line executed"
}


print "PASS: after IF block"
print ""

// ─────────────────────────────────────────────
// Test 2: Basic multi-line IF — condition false
// ─────────────────────────────────────────────
print "--- Test 2: Basic IF false ---"
var b : Int = 2
if (b > 5) {
    print "FAIL: should not print"
    print "FAIL: should not print"
}
print "PASS: skipped false IF block"
print ""

// ─────────────────────────────────────────────
// Test 3: Multi-line IF after WHILE
// ─────────────────────────────────────────────
print "--- Test 3: IF after WHILE ---"
var i : Int = 0
var sum : Int = 0
while (i < 5) {
    sum = sum + i
    i = i + 1
}
if (sum == 10) {
    print "PASS: WHILE sum correct = " + STR$(sum)
}
if (sum <> 10) {
    print "FAIL: WHILE sum wrong = " + STR$(sum)
}
print ""

// ─────────────────────────────────────────────
// Test 4: WHILE inside multi-line IF
// ─────────────────────────────────────────────
print "--- Test 4: WHILE inside IF ---"
var flag : Int = 1
var count : Int = 0
if (flag == 1) {
    var j : Int = 0
    while (j < 4) {
        count = count + 1
        j = j + 1
    }
    print "PASS: WHILE inside IF ran " + STR$(count) + " times"
}
if (count <> 4) {
    print "FAIL: count should be 4, got " + STR$(count)
}
print ""

// ─────────────────────────────────────────────
// Test 5: Nested multi-line IF
// ─────────────────────────────────────────────
print "--- Test 5: Nested IF ---"
var x : Int = 10
var y : Int = 20
if (x < y) {
    print "PASS: outer IF true"
    if (y == 20) {
        print "PASS: inner IF true"
    }
    if (y == 99) {
        print "FAIL: inner IF false should skip"
    }
    print "PASS: after inner IF"
}
print ""

// ─────────────────────────────────────────────
// Test 6: IF inside WHILE
// ─────────────────────────────────────────────
print "--- Test 6: IF inside WHILE ---"
var k : Int = 0
var evens : Int = 0
var odds  : Int = 0
while (k < 10) {
    if (k % 2 == 0) {
        evens = evens + 1
    }
    if (k % 2 <> 0) {
        odds = odds + 1
    }
    k = k + 1
}
print "PASS: evens = " + STR$(evens) + " (expect 5)"
print "PASS: odds  = " + STR$(odds)  + " (expect 5)"
if (evens <> 5) {
    print "FAIL: evens wrong"
}
if (odds <> 5) {
    print "FAIL: odds wrong"
}
print ""

// ─────────────────────────────────────────────
// Test 7: Single-line IF THEN still works
// ─────────────────────────────────────────────
print "--- Test 7: Single-line IF THEN ---"
var n : Int = 7
if n > 5 then print "PASS: single-line IF THEN true"
if n < 5 then print "FAIL: single-line IF THEN false should skip"
var t$ : String = ""
if n == 7 then t$ = "assigned"
if (t$ == "assigned") {
    print "PASS: single-line IF THEN assignment: " + t$
}
print ""

// ─────────────────────────────────────────────
// Test 8: Multi-line IF with function call
// ─────────────────────────────────────────────
print "--- Test 8: IF with function call ---"
var result : Int = 0
result = double(6)
if (result == 12) {
    print "PASS: func result correct = " + STR$(result)
}
if (result <> 12) {
    print "FAIL: func result wrong = " + STR$(result)
}
print ""

// ─────────────────────────────────────────────
// Test 9: Deeply nested IF and WHILE
// ─────────────────────────────────────────────
print "--- Test 9: Deeply nested IF + WHILE ---"
var total : Int = 0
var p : Int = 1
while (p <= 3) {
    if (p == 1) {
        total = total + 100
    }
    if (p == 2) {
        var q : Int = 0
        while (q < 3) {
            total = total + 10
            q = q + 1
        }
    }
    if (p == 3) {
        total = total + 1
    }
    p = p + 1
}
print "PASS: total = " + STR$(total) + " (expect 131)"
if (total <> 131) {
    print "FAIL: total wrong, got " + STR$(total)
}
print ""

// ─────────────────────────────────────────────
// Test 10: Multi-line IF in a function
// ─────────────────────────────────────────────
print "--- Test 10: Multi-line IF in function ---"
print classify(15)
print classify(7)
print classify(2)
print ""

// ─────────────────────────────────────────────
// Test 11: IF with string comparison
// ─────────────────────────────────────────────
print "--- Test 11: IF with string comparison ---"
var s$ : String = "hello"
if (s$ == "hello") {
    print "PASS: string comparison true"
    var s2$ : String = "world"
    if (s2$ == "world") {
        print "PASS: nested string comparison true"
    }
}
if (s$ == "goodbye") {
    print "FAIL: should not execute"
}
print ""

print "============================================"
print "  Milestone 39 Tests Complete"
print "============================================"
end

func double(n) {
    return n * 2
}

func classify(n) {
    var result$ : String = ""
    if (n > 10) {
        result$ = "big: " + STR$(n)
    }
    if (n > 4) {
        if (n <= 10) {
            result$ = "medium: " + STR$(n)
        }
    }
    if (n <= 4) {
        result$ = "small: " + STR$(n)
    }
    return result$
}
