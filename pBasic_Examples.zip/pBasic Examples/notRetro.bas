// notRetro.bas

func peace(a$) {
	return a$ + "✌🏻"
}

var b$ = "pBASIC is a modern basic, not a retro basic. "
for n = 1 to 7
	tab(n)
	print peace(b$)
next n
