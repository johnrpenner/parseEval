// ptest_v10.bas — pScript Milestone 10 Regression Test Suite
// Tests all features through Milestone 10 (WHILE loop)
// Run: pscript ptest_v10.bas
// All tests should PASS. Any FAIL indicates a regression.
// Copyright 2026 John Roland Penner

// ─────────────────────────────────────────────
// TEST HARNESS
// ─────────────────────────────────────────────
var passed : Int = 0
var failed : Int = 0
var total  : Int = 0

func check(label$, got, expected) {
    var result : Int = 0
    if got == expected then result = 1
    if result == 1 then passed = passed + 1
    if result == 0 then failed = failed + 1
    total = total + 1
    if result == 0 then print "  FAIL: "; 
    if result == 0 then print label$
    if result == 1 then print "  pass: ";
    if result == 1 then print label$
    return result
}

func checkStr(label$, got$, expected$) {
    var result : Int = 0
    if got$ == expected$ then result = 1
    if result == 1 then passed = passed + 1
    if result == 0 then failed = failed + 1
    total = total + 1
    if result == 0 then print "  FAIL: ";
    if result == 0 then print label$
    if result == 1 then print "  pass: ";
    if result == 1 then print label$
    return result
}


// ─────────────────────────────────────────────
// SECTION 1 — VARIABLES & TYPES
// ─────────────────────────────────────────────
print "--- 1. Variables & Types ---"

var i1 : Int   = 42
var f1 : Float = 3.14
var s1 : String = "hello"
var b1 : Bool  = 1

check("Int declaration",   i1, 42)
check("Float declaration", f1, 3.14)
checkStr("String declaration", s1, "hello")
check("Bool declaration",  b1, 1)

var i2 : Int = 0
i2 = 99
check("Int assignment", i2, 99)

var f2 : Float = 0.0
f2 = 2.718
check("Float assignment", f2, 2.718)

var s2 : String = ""
s2 = "world"
checkStr("String assignment", s2, "world")


// ─────────────────────────────────────────────
// SECTION 2 — ARITHMETIC
// ─────────────────────────────────────────────
print "--- 2. Arithmetic ---"

var r : Float = 0.0
r = 2 + 3
check("Addition",       r, 5)
r = 10 - 4
check("Subtraction",    r, 6)
r = 3 * 7
check("Multiplication", r, 21)
r = 20 / 4
check("Division",       r, 5)
r = 2 ^ 8
check("Power",          r, 256)
r = -5 + 2
check("Unary minus",    r, -3)

// Operator precedence
r = 2 + 3 * 4
check("Precedence * before +", r, 14)
r = (2 + 3) * 4
check("Parentheses override",  r, 20)
r = 10 - 3 - 2
check("Left-assoc subtraction", r, 5)


// ─────────────────────────────────────────────
// SECTION 3 — COMPARISON OPERATORS
// ─────────────────────────────────────────────
print "--- 3. Comparison Operators ---"

check("== true",  1 == 1, 1)
check("== false", 1 == 2, 0)
check("<> true",  1 <> 2, 1)
check("<> false", 1 <> 1, 0)
check("> true",   5 > 3,  1)
check("> false",  3 > 5,  0)
check("< true",   3 < 5,  1)
check("< false",  5 < 3,  0)
check(">= equal", 5 >= 5, 1)
check(">= greater",6 >= 5,1)
check(">= false", 4 >= 5, 0)
check("<= equal", 5 <= 5, 1)
check("<= less",  4 <= 5, 1)
check("<= false", 6 <= 5, 0)


// ─────────────────────────────────────────────
// SECTION 4 — MATH FUNCTIONS
// ─────────────────────────────────────────────
print "--- 4. Math Functions ---"

var mf : Float = 0.0
mf = ABS(-7.5)
check("ABS negative", mf, 7.5)
mf = ABS(3.0)
check("ABS positive", mf, 3.0)
mf = INT(4.9)
check("INT floor",    mf, 4)
mf = INT(-4.1)
check("INT neg floor",mf, -5)
mf = SQR(9.0)
check("SQR square",   mf, 81)
mf = SQRT(81.0)
check("SQRT",         mf, 9)
mf = SIN(0.0)
check("SIN(0)",       mf, 0)
mf = COS(0.0)
check("COS(0)",       mf, 1)
mf = EXP(0.0)
check("EXP(0)",       mf, 1)
mf = LOG(1.0)
check("LOG(1)",       mf, 0)
mf = ABS(PI - 3.14159265)
check("PI approx",    mf < 0.0001, 1)

// RND: just check it returns a value in [0,1)
var rndv : Float = RND(0)
var rndok : Int = 0
if rndv >= 0 then rndok = 1
check("RND in range", rndok, 1)
check("RND < 1",      rndv < 1, 1)


// ─────────────────────────────────────────────
// SECTION 5 — STRING OPERATIONS
// ─────────────────────────────────────────────
print "--- 5. String Operations ---"

var sa : String = "Hello"
var sb : String = " World"
var sc : String = ""
sc = sa + sb
checkStr("String concat",     sc, "Hello World")
check("LEN basic",            LEN("pScript"), 7)
check("LEN empty",            LEN(""), 0)
checkStr("MID$ middle",       MID$("pScript", 1, 3), "Scr")
checkStr("MID$ from start",   MID$("Hello", 0, 5), "Hello")
checkStr("MID$ single char",  MID$("BASIC", 2, 1), "S")
checkStr("MID$ past end",     MID$("Hi", 0, 99), "Hi")

var slen : Int = 0
slen = LEN(sa)
check("LEN of var", slen, 5)


// ─────────────────────────────────────────────
// SECTION 6 — FOR / NEXT
// ─────────────────────────────────────────────
print "--- 6. FOR / NEXT ---"

var fsum : Int = 0
for i = 1 to 5
    fsum = fsum + i
next i
check("FOR sum 1-5", fsum, 15)

// Counting down with STEP
var fdown : Int = 0
for j = 10 to 1 step -1
    fdown = fdown + 1
next j
check("FOR STEP -1 count", fdown, 10)

// STEP 2
var fevens : Int = 0
for k = 2 to 10 step 2
    fevens = fevens + k
next k
check("FOR STEP 2 even sum", fevens, 30)

// Zero iterations (start > end, positive step)
var fzero : Int = 0
for z = 5 to 1
    fzero = fzero + 1
next z
check("FOR zero iterations", fzero, 0)

// Nested FOR loops
var fmat : Int = 0
for row = 1 to 3
    for col = 1 to 3
        fmat = fmat + 1
    next col
next row
check("Nested FOR 3x3", fmat, 9)


// ─────────────────────────────────────────────
// SECTION 7 — IF / THEN
// ─────────────────────────────────────────────
print "--- 7. IF / THEN ---"

var ifv : Int = 0
if 1 == 1 then ifv = 1
check("IF true executes",  ifv, 1)
if 1 == 2 then ifv = 99
check("IF false skips",    ifv, 1)

var ifv2 : Int = 0
if 10 > 5 then ifv2 = 10
check("IF > condition",    ifv2, 10)

var ifv3 : Int = 0
if 3 <> 5 then ifv3 = 1
check("IF <> condition",   ifv3, 1)

// IF with RETURN inside function (tested in section 9)


// ─────────────────────────────────────────────
// SECTION 8 — ARRAYS
// ─────────────────────────────────────────────
print "--- 8. Arrays ---"

var iarr[5] : Int
iarr[0] = 10
iarr[1] = 20
iarr[2] = 30
iarr[3] = 40
iarr[4] = 50
check("Int array store/load [0]", iarr[0], 10)
check("Int array store/load [4]", iarr[4], 50)

// Compute sum via array
var asum : Int = 0
for ai = 0 to 4
    asum = asum + iarr[ai]
next ai
check("Int array sum", asum, 150)

var farr[3] : Float
farr[0] = 1.1
farr[1] = 2.2
farr[2] = 3.3
check("Float array [0]", farr[0], 1.1)
check("Float array [2]", farr[2], 3.3)

var sarr[3] : String
sarr[0] = "one"
sarr[1] = "two"
sarr[2] = "three"
checkStr("String array [0]", sarr[0], "one")
checkStr("String array [2]", sarr[2], "three")

// Overwrite element
iarr[2] = 999
check("Array element overwrite", iarr[2], 999)


// ─────────────────────────────────────────────
// SECTION 9 — FUNCTIONS
// ─────────────────────────────────────────────
print "--- 9. Functions ---"

// Basic function with one param
func double(x) {
    return x * 2
}
check("func double(5)",  double(5),  10)
check("func double(0)",  double(0),  0)
check("func double(-3)", double(-3), -6)

// Two params
func add(a, b) {
    return a + b
}
check("func add(3,4)",   add(3, 4),  7)
check("func add(-1,1)",  add(-1, 1), 0)

// Zero params
func getFortyTwo() {
    return 42
}
check("func no params", getFortyTwo(), 42)

// Function with local var
func sumTo(n) {
    var total : Int = 0
    var i2    : Int = 1
    while (i2 <= n) {
        total = total + i2
        i2 = i2 + 1
    }
    return total
}
check("func sumTo(5)",  sumTo(5),  15)
check("func sumTo(10)", sumTo(10), 55)

// Recursion — factorial
func fact(n) {
    if n <= 1 then return 1
    return n * fact(n - 1)
}
check("fact(1)",  fact(1),  1)
check("fact(5)",  fact(5),  120)
check("fact(10)", fact(10), 3628800)

// Fibonacci (recursive)
func fib(n) {
    if n <= 0 then return 0
    if n == 1 then return 1
    return fib(n - 1) + fib(n - 2)
}
check("fib(0)",  fib(0),  0)
check("fib(1)",  fib(1),  1)
check("fib(7)",  fib(7),  13)
check("fib(10)", fib(10), 55)

// String-returning function
func greet(name$) {
    var g$ : String = "Hi " + name$
    return g$
}
checkStr("func returns string", greet("Bob"), "Hi Bob")

// Function result used in expression
check("func in expr", double(3) + double(4), 14)

// Mutual use — function calls another function
func triple(x) {
    return add(double(x), x)
}
check("func calls func", triple(4), 12)


// ─────────────────────────────────────────────
// SECTION 10 — WHILE LOOP
// ─────────────────────────────────────────────
print "--- 10. WHILE Loop ---"

// Basic counting loop
var wa : Int = 0
var wcount : Int = 0
wa = 1
while (wa <= 5) {
    wcount = wcount + 1
    wa = wa + 1
}
check("WHILE count 1-5", wcount, 5)

// Zero iterations (condition false at start)
var wnever : Int = 0
var wn : Int = 10
while (wn < 5) {
    wnever = wnever + 1
}
check("WHILE zero iterations", wnever, 0)

// Sum accumulation (matches whiletest.bas)
var wA : Int = 5
var wsum : Int = 0
while (wA < 20) {
    wsum = wsum + wA
    wA = wA + 1
}
check("WHILE sum 5..19", wsum, 180)

// Nested WHILE
var outer : Int = 0
var inner : Int = 0
var wcells : Int = 0
outer = 1
while (outer <= 3) {
    inner = 1
    while (inner <= 3) {
        wcells = wcells + 1
        inner = inner + 1
    }
    outer = outer + 1
}
check("Nested WHILE 3x3", wcells, 9)

// WHILE inside a function (Milestone 10 key requirement)
func whileSum(n) {
    var s : Int = 0
    var i3 : Int = 1
    while (i3 <= n) {
        s = s + i3
        i3 = i3 + 1
    }
    return s
}
check("WHILE inside func, n=5",  whileSum(5),  15)
check("WHILE inside func, n=10", whileSum(10), 55)
check("WHILE inside func, n=100",whileSum(100),5050)

// WHILE with FOR inside
var wfsum : Int = 0
var wfi : Int = 1
while (wfi <= 3) {
    for fi2 = 1 to wfi
        wfsum = wfsum + 1
    next fi2
    wfi = wfi + 1
}
check("WHILE with FOR inside", wfsum, 6)

// FOR with WHILE inside
var fwsum : Int = 0
var fwj : Int = 1
for fwi = 1 to 3
    fwj = 1
    while (fwj <= fwi) {
        fwsum = fwsum + 1
        fwj = fwj + 1
    }
next fwi
check("FOR with WHILE inside", fwsum, 6)

// WHILE: condition uses string length
var ws$ : String = ""
var wsc : Int = 0
while (LEN(ws$) < 5) {
    ws$ = ws$ + "x"
    wsc = wsc + 1
}
check("WHILE on string length", wsc, 5)
checkStr("WHILE built string", ws$, "xxxxx")


// ─────────────────────────────────────────────
// SECTION 11 — CONSTANTS & BUILT-INS
// ─────────────────────────────────────────────
print "--- 11. Constants & Built-ins ---"

// PI
var pitest : Float = 0.0
pitest = ABS(PI - 3.14159265358979)
check("PI value precision", pitest < 1e-10, 1)

// DATE and TIME are non-deterministic — just check they are non-empty strings
var ds$ : String = DATE
var ts$ : String = TIME
check("DATE non-empty",  LEN(ds$) > 0, 1)
check("TIME non-empty",  LEN(ts$) > 0, 1)
check("TIME has colons", MID$(ts$, 2, 1) == ":", 1)


// ─────────────────────────────────────────────
// SECTION 12 — EDGE CASES & STRESS
// ─────────────────────────────────────────────
print "--- 12. Edge Cases ---"

// Integer boundary
var big : Int = 0
big = 1000000
big = big * 1000
check("Large int 1e9", big, 1000000000)

// Negative step in WHILE (countdown)
var cd : Int = 10
var cdcount : Int = 0
while (cd > 0) {
    cdcount = cdcount + 1
    cd = cd - 1
}
check("WHILE countdown from 10", cdcount, 10)
check("WHILE countdown result",  cd,      0)

// Float precision
var fptest : Float = 0.0
fptest = ABS((0.1 + 0.2) - 0.3)
check("Float 0.1+0.2 near 0.3", fptest < 1e-10, 1)

// String length after concat in loop
var catstr$ : String = ""
var cati : Int = 0
while (cati < 4) {
    catstr$ = catstr$ + "ab"
    cati = cati + 1
}
check("String built in WHILE", LEN(catstr$), 8)

// Deep recursion (tests call stack discipline)
func countDown(n) {
    if n <= 0 then return 0
    return 1 + countDown(n - 1)
}
check("Recursion depth 20",  countDown(20),  20)
check("Recursion depth 50",  countDown(50),  50)

// Function result in array store
var resarr[5] : Int
var ri : Int = 0
while (ri < 5) {
    resarr[ri] = double(ri)
    ri = ri + 1
}
check("Array[0] from func", resarr[0], 0)
check("Array[3] from func", resarr[3], 6)
check("Array[4] from func", resarr[4], 8)


// ─────────────────────────────────────────────
// SUMMARY
// ─────────────────────────────────────────────
print ""
print "================================"
print "pScript v0.10 Test Results"
print "================================"
print "Passed: ";
print passed
print "Failed: ";
print failed
print "Total:  ";
print total
print "================================"
if failed == 0 then print "ALL TESTS PASSED"
if failed > 0  then print "REGRESSIONS DETECTED"
print ""
