print "=== pBasic v0.6.0 Comprehensive Test Suite ==="
print ""

print "Test 1: Variable Types"
var a : Int = 42
var b : Float = 3.14159
var name$ = "pBasic"
var flag : Bool = 1
print a
print b
print name$
print flag
print ""

print "Test 2: Arithmetic Operations"
var x : Int = 10
var y : Int = 3
print x + y
print x - y
print x * y
print x / y
print x ^ 2
print ""

print "Test 3: Comparison Operators"
print "5 > 3 ="
print 5 > 3
print "5 < 3 ="
print 5 < 3
print "5 == 5 ="
print 5 == 5
print "5 >= 5 ="
print 5 >= 5
print "5 <= 4 ="
print 5 <= 4
print "5 <> 3 ="
print 5 <> 3
print ""

print "Test 4: Math Functions"
print "sin(pi/2) ="
print sin(pi * 0.5)
print "cos(pi) ="
print cos(pi)
print "sqrt(16) ="
print sqrt(16)
print "abs(-5) ="
print abs(-5)
print "sqr(4) ="
print sqr(4)
print "exp(1) ="
print exp(1)
print "log(2.718) ="
print log(2.718)
print ""

print "Test 5: FOR Loop - Simple"
for i = 1 to 5
print i
next i
print ""

print "Test 6: FOR Loop - With Variable"
var limit : Int = 3
for j = 1 to limit
print j * 2
next j
print ""

print "Test 7: FOR Loop - Countdown"
for k = 5 to 1 step -1
print k
next k
print ""

print "Test 8: Nested FOR Loops"
for outer = 1 to 3
for inner = 1 to 2
print outer * 10 + inner
next inner
next outer
print ""

print "Test 9: IF/THEN"
var score : Int = 85
if score > 90 then print "A Grade"
if score > 80 then print "B Grade"
if score > 70 then print "C Grade"
if score < 60 then print "Failed"
print ""

print "Test 10: Variable Assignment"
var counter : Int = 0
counter = 5
print counter
counter = counter + 10
print counter
counter = counter * 2
print counter
print ""

print "Test 11: Expression Evaluation"
var result : Float = 0.0
result = (10 + 5) * 2 / 3
print result
result = 2 ^ 3 + 1
print result
print ""

print "Test 12: String Variables"
var greeting$ = "Hello"
var target$ = "World"
print greeting$
print target$
print ""

print "Test 13: RND() Random Numbers"
print "5 random values:"
for r = 1 to 5
print rnd(1)
next r
print ""

print "Test 14: RND() Coin Flip (10 flips)"
var heads : Int = 0
var tails : Int = 0
for flip = 1 to 10
var coin : Float = rnd(1)
if coin > 0.5 then heads = heads + 1
if coin <= 0.5 then tails = tails + 1
next flip
print "Heads:"
print heads
print "Tails:"
print tails
print ""

print "Test 15: Int Array - Declaration and Access"
var nums[5] : Int
nums[0] = 10
nums[1] = 20
nums[2] = 30
nums[3] = 40
nums[4] = 50
print "Expected: 10, 20, 30, 40, 50"
for i = 0 to 4
print nums[i]
next i
print ""

print "Test 16: Float Array"
var prices[3] : Float
prices[0] = 9.99
prices[1] = 19.95
prices[2] = 5.50
print "Expected: 9.99, 19.95, 5.50"
for i = 0 to 2
print prices[i]
next i
print ""

print "Test 17: Array with Variable Index"
var data[4] : Int
data[0] = 100
data[1] = 200
data[2] = 300
data[3] = 400
var idx : Int = 2
print "data[2] should be 300:"
print data[idx]
print ""

print "Test 18: Array in Loop - Squares"
var squares[5] : Int
for n = 0 to 4
squares[n] = n * n
next n
print "Expected: 0, 1, 4, 9, 16"
for n = 0 to 4
print squares[n]
next n
print ""

print "Test 19: Array Sum"
var values[5] : Int
values[0] = 5
values[1] = 10
values[2] = 15
values[3] = 20
values[4] = 25
var sum : Int = 0
for i = 0 to 4
sum = sum + values[i]
next i
print "Sum should be 75:"
print sum
print ""

print "Test 20: String Array"
var words[3] : String
words[0] = "one"
words[1] = "two"
words[2] = "three"
print "Expected: one, two, three"
for i = 0 to 2
print words[i]
next i
print ""

print "=== All 20 Tests Complete ==="
