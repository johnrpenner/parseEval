// ============================================================
// pBasic v0.7.0 — Complete Language Validation Suite
// Tests all implemented features in order of milestone
// ============================================================

print "============================================"
print "  pBasic v0.7.0 — Complete Validation Suite"
print "============================================"
print ""

// ============================================================
// SECTION 1: Variable Declarations & Basic Types
// ============================================================
print "--- Section 1: Variables & Types ---"

var a : Int = 42
var b : Float = 3.14
var c : Bool = 1
var d$ = "hello"
var e : Int = 0

print a
print b
print c
print d$
// Expected: 42  3.14  1  hello

print ""

// ============================================================
// SECTION 2: Arithmetic Operators
// ============================================================
print "--- Section 2: Arithmetic ---"

var r1 : Float = 0.0
var r2 : Float = 0.0
var r3 : Float = 0.0
var r4 : Float = 0.0
var r5 : Float = 0.0

r1 = 10 + 3
r2 = 10 - 3
r3 = 10 * 3
r4 = 10 / 4
r5 = 2 ^ 8

print r1
print r2
print r3
print r4
print r5
// Expected: 13  7  30  2.5  256

print ""

// ============================================================
// SECTION 3: Comparison Operators
// ============================================================
print "--- Section 3: Comparisons ---"

var t1 : Int = 0
var t2 : Int = 0
var t3 : Int = 0
var t4 : Int = 0
var t5 : Int = 0
var t6 : Int = 0

t1 = 5 == 5
t2 = 5 <> 4
t3 = 7 > 3
t4 = 2 < 9
t5 = 6 >= 6
t6 = 4 <= 5

print t1
print t2
print t3
print t4
print t5
print t6
// Expected: 1 1 1 1 1 1

print ""

// ============================================================
// SECTION 4: String Operations
// ============================================================
print "--- Section 4: Strings ---"

var s1$ = "foo"
var s2$ = "bar"
var s3$ = ""
var s4$ = ""
var slen : Int = 0

s3$ = s1$ + s2$
print s3$
// Expected: foobar

s4$ = "Hello" + ", " + "World!"
print s4$
// Expected: Hello, World!

slen = LEN("pBasic")
print slen
// Expected: 6

var sub$ = ""
sub$ = MID$("abcdefgh", 2, 4)
print sub$
// Expected: cdef

print ""

// ============================================================
// SECTION 5: IF / THEN
// ============================================================
print "--- Section 5: IF / THEN ---"

var x : Int = 10

if x == 10 then print "x is ten"
if x > 5 then print "x is greater than 5"
if x < 5 then print "should not print"
if x <> 99 then print "x is not 99"
// Expected: x is ten / x is greater than 5 / x is not 99

var flag : Int = 0
if x >= 10 then flag = 1
print flag
// Expected: 1

print ""

// ============================================================
// SECTION 6: FOR / NEXT Loops
// ============================================================
print "--- Section 6: FOR / NEXT ---"

var total : Int = 0
for i = 1 to 5
total = total + i
next i
print total
// Expected: 15

// Count down with STEP
var countdown : Int = 0
for j = 10 to 2 step -2
print j;
print " ";
next j
print ""
// Expected: 10 8 6 4 2

// Nested loops
var pairs : Int = 0
for p = 1 to 3
for q = 1 to 3
pairs = pairs + 1
next q
next p
print pairs
// Expected: 9

print ""

// ============================================================
// SECTION 7: Math Built-ins
// ============================================================
print "--- Section 7: Math Built-ins ---"

var m1 : Float = 0.0
var m2 : Float = 0.0
var m3 : Float = 0.0
var m4 : Float = 0.0
var m5 : Float = 0.0
var m6 : Float = 0.0
var m7 : Float = 0.0

m1 = ABS(-7)
m2 = INT(3.9)
m3 = SQRT(144)
m4 = SQR(9)
m5 = EXP(1)
m6 = LOG(1)
m7 = LOG10(1000)

print m1
print m2
print m3
print m4
print m5
print m6
print m7
// Expected: 7  3  12  81  2.71828  0  3

print ""

// Trig
var trig1 : Float = 0.0
var trig2 : Float = 0.0
var trig3 : Float = 0.0

trig1 = SIN(0)
trig2 = COS(0)
trig3 = ATAN(1) * 4
print trig1
print trig2
print trig3
// Expected: 0  1  3.14159

print ""

// ============================================================
// SECTION 8: Constants (PI, DATE, TIME)
// ============================================================
print "--- Section 8: Constants ---"

var ppp : Float = 0.0
ppp = PI
print ppp
// Expected: 3.14159

var today$ = ""
var now$ = ""
today$ = DATE
now$ = TIME
print today$
print now$
// Expected: current date and time strings

print ""

// ============================================================
// SECTION 9: Arrays
// ============================================================
print "--- Section 9: Arrays ---"

var nums[5] : Int
var strs[3] : String

nums[0] = 100
nums[1] = 200
nums[2] = 300
nums[3] = 400
nums[4] = 500

print nums[0]
print nums[2]
print nums[4]
// Expected: 100  300  500

strs[0] = "alpha"
strs[1] = "beta"
strs[2] = "gamma"
print strs[0]
print strs[1]
print strs[2]
// Expected: alpha  beta  gamma

// Array sum via loop
var arrsum : Int = 0
for k = 0 to 4
arrsum = arrsum + nums[k]
next k
print arrsum
// Expected: 1500

print ""

// ============================================================
// SECTION 10: TAB
// ============================================================
print "--- Section 10: TAB ---"

tab(5)
print "A"
tab(10)
print "B"
tab(15)
print "C"
// Expected: columns at 5, 10, 15

print ""

// ============================================================
// SECTION 11: Functions — Basic
// ============================================================
print "--- Section 11: Functions (Basic) ---"

var f1 : Float = 0.0
var f2 : Float = 0.0
var f3 : Float = 0.0

f1 = double(7)
f2 = sumThree(1, 2, 3)
f3 = hypotenuse(3, 4)

print f1
print f2
print f3
// Expected: 14  6  5

print ""

// ============================================================
// SECTION 12: Functions — Expressions & Nesting
// ============================================================
print "--- Section 12: Functions in Expressions ---"

var e1 : Float = 0.0
var e2 : Float = 0.0
var e3 : Float = 0.0

e1 = double(3) + double(4)
e2 = double(sumThree(1, 2, 3))
e3 = hypotenuse(double(3), double(2))

print e1
print e2
print e3
// Expected: 14  12  ~7.2111

print ""

// ============================================================
// SECTION 13: Functions — Local Scope
// ============================================================
print "--- Section 13: Local Scope ---"

var gx : Int = 555
var gy : Int = 777
var ls_result : Int = 0

ls_result = scopeTest(10)
print ls_result
// Expected: 100  (10 * 10, using local gx shadow)
print gx
// Expected: 555  (global unchanged)
print gy
// Expected: 777  (global unchanged)

print ""

// ============================================================
// SECTION 14: Functions — String Return
// ============================================================
print "--- Section 14: String Functions ---"

var title$ = ""
var shout$ = ""

title$ = prefix("World", "Hello ")
shout$ = shout("quiet")

print title$
print shout$
// Expected: Hello World  QUIET

print ""

// ============================================================
// SECTION 15: Functions — Recursion
// ============================================================
print "--- Section 15: Recursion ---"

var fact5 : Float = 0.0
var fact10 : Float = 0.0
var fib8 : Float = 0.0
var fib12 : Float = 0.0

fact5 = factorial(5)
fact10 = factorial(10)
fib8 = fib(8)
fib12 = fib(12)

print fact5
print fact10
print fib8
print fib12
// Expected: 120  3628800  21  144

print ""

// ============================================================
// SECTION 16: Functions — Used in FOR Loops & IF Conditions
// ============================================================
print "--- Section 16: Functions in Control Flow ---"

var loop_sum : Float = 0.0
for n = 1 to 6
loop_sum = loop_sum + factorial(n)
next n
print loop_sum
// Expected: 873  (1+2+6+24+120+720)

var big : Int = 0
if factorial(6) > 700 then big = 1
print big
// Expected: 1

print ""

// ============================================================
// SECTION 17: Print Formatting
// ============================================================
print "--- Section 17: Print Formatting ---"

print "A";
print "B";
print "C"
// Expected: ABC on one line

var line$ = ""
line$ = "Value: " + "42"
print line$
// Expected: Value: 42

print ""

// ============================================================
// FUNCTION DEFINITIONS
// (pre-scanned — order in file doesn't matter)
// ============================================================

func double(N) {
    var result : Float = 0.0
    result = N * 2
    return result
}

func sumThree(A, B, C) {
    var s : Float = 0.0
    s = A + B + C
    return s
}

func hypotenuse(A, B) {
    var h : Float = 0.0
    h = SQRT(A * A + B * B)
    return h
}

func scopeTest(gx) {
    // local gx shadows global gx; local gy is separate
    var gy : Int = 0
    gy = gx * gx
    return gy
}

func prefix(word$, pre$) {
    var out$ = ""
    out$ = pre$ + word$
    return out$
}

func shout(s$) {
    // Return length as a proxy for string upper — demonstrates string param/return
    // (pBasic has no UCASE yet, so we build "QUIET" manually for the test)
    var out$ = ""
    out$ = "QUIET"
    return out$
}

func factorial(N) {
    var result : Float = 0.0
    if N <= 1 then result = 1
    if N > 1 then result = N * factorial(N - 1)
    return result
}

func fib(N) {
    var result : Float = 0.0
    if N <= 0 then result = 0
    if N == 1 then result = 1
    if N > 1 then result = fib(N - 1) + fib(N - 2)
    return result
}

// ============================================================
// SINEWAVE VISUALIZER
// ============================================================

print "=== Sine Wave Visualizer ==="
print ""
var freq : Float = 0.3
var amp : Float = 10.0
var offset : Float = 15.0
var value : Float = 0.0
var spaces : Int = 0
for n = 0 to 20
	value = sin(n * freq) * amp + offset
	tab(value)
	print "*"
next n
print ""
print "Wave complete!"

