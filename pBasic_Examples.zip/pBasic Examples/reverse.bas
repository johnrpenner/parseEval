var a$ = ""
input a$
var b$ = ""
print "hello ";
for n = len(a$) - 1 to 0 step -1
b$ = b$ + mid$(a$, n, 1)
next n
print b$
exit
