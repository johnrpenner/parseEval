// schrafField.bas
// pBasic version of Field Lines, based on Kurt Moerman's Demo. 
// From: Eric Schraf's QB64 Implementation of Jean-Paul Delahaye's
// Geometric and artistic drawings with your microcomputers (1980), 
// for the CANON X07. Translated to QB64 w help of Julien Gachadoat. 

CLS
PEN 3.0
print "Schraf Field Lines"
print "ESC to quit"

var np    : Float = 800.0
var nn    : Float = 240.0
var mm    : Float = 60.0
var kk    : Float = 0.02
var pi    : Float = 3.1415926
var zPen  : Float = 2.0

var offX    : Float = (1260.0 - np) / 2.0
var hueStep  : Float = 60.0 / nn
var hueCycle : Float = 0.0

var running : Int = 1
var k$      : String = ""

var x     : Float = 0.0
var y     : Float = 0.0
var xx    : Float = 0.0
var yy    : Float = 0.0
var an    : Float = 0.0
var rdist : Float = 0.0
var hue   : Float = 0.0
var rr    : Float = 0.0
var gg    : Float = 0.0
var bb    : Float = 0.0

var prevSX : Float = 0.0
var prevSY : Float = 0.0
var currSX : Float = 0.0
var currSY : Float = 0.0

var bail  : Int = 0

while (running == 1) {
    k$ = INKEY$
    if k$ == "ESC" then running = 0

    BUFFER:1
    CLR

    hueCycle = 0.0
	
	for nn = 1 to 900
	
    var ii : Int = 0
    for ii = 0 to nn
        x = RND(1)
        y = RND(1)
        bail = 0

        hue = hueCycle
        setHSBColor()
        zPen = 8.0
        PEN zPen

        var jj : Int = 0
        for jj = 0 to mm
            if bail == 1 then jj = mm + 1

            if bail == 0 then currSX = offX + np * x
            if bail == 0 then currSY = np * y + 100

            if jj > 0 then LINE(prevSX, prevSY, currSX, currSY, rr, gg, bb, 1.0)

            if bail == 0 then prevSX = currSX
            if bail == 0 then prevSY = currSY

            if bail == 0 then xx = 2.0 * x - 1.0
            if bail == 0 then yy = 2.0 * y - 1.0

            if bail == 0 then an = ATAN(yy / (xx + 0.000001))
            if xx == 0 then an = pi / 2.0 * sign(yy)
            if xx < 0 then an = an + pi * sign(yy)

            if bail == 0 then rdist = SQR(xx * xx + yy * yy)
            if bail == 0 then an = an + 4.0 * pi / 3.0 + SIN(6.0 * pi * rdist) / 4.0

            if bail == 0 then x = x + kk * COS(an)
            if bail == 0 then y = y + kk * SIN(an)

            if x <= 0.0 then bail = 1
            if x >= 1.0 then bail = 1
            if y <= 0.0 then bail = 1
            if y >= 1.0 then bail = 1

            jj = jj + 1
            
            if zPen > 0.75 then zPen = zPen - 0.18
            PEN zPen
        next jj

        hueCycle = hueCycle + hueStep
        if hueCycle > 270.0 then hueCycle = 0.0
		
        BUFFER
		
    next ii
    
    CLR
    next nn
}

print ""
print "Cheerio!"
end

// ── Sign function ───────────────────────────────────────────────────────────
func sign(val) {
    var retValue : Float = 0.0
    if val > 0.0 then retValue = 1.0
    if val < 0.0 then retValue = -1.0
    return retValue
}

// ── HSB colour helper ───────────────────────────────────────────────────────
func setHSBColor() {
    rr = 0.0
    gg = 0.0
    bb = 0.0
    if hue < 120.0 then rr = 1.0 - hue / 120.0
    if hue < 120.0 then gg = hue / 120.0
    if hue < 120.0 then bb = 0.0
    if hue >= 120.0 then rr = 0.0
    if hue >= 120.0 then gg = 1.0 - (hue - 120.0) / 120.0
    if hue >= 120.0 then bb = (hue - 120.0) / 120.0
    if hue >= 240.0 then rr = (hue - 240.0) / 120.0
    if hue >= 240.0 then gg = 0.0
    if hue >= 240.0 then bb = 1.0 - (hue - 240.0) / 120.0
    return 0
}
