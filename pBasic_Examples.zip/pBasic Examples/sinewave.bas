// sinewave.bas - ASCII Sine Wave Generator
print "=== Sine Wave Visualizer ==="
print ""

var freq : Float = 0.3
var amp : Float = 10.0
var offset : Float = 15.0
var value : Float = 0.0
var spaces : Int = 0

for n = 0 to 40
	value = sin(n * freq) * amp + offset
	tab(value)
	print "*"
next n

print ""
print "Wave complete!"
