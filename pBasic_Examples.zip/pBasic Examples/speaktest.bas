// say_test.bas
var h$ : String = "Hello. I am pBasic."
SAY h$

var g$ : String = ""

SAY "The time is: " + TIME

var n : Int = 1
while (n <= 5) {
	g$ = "Count: " + str$(n)
	print g$
    SAY g$
    n = n + 1
}
SAY "Goodbye."
end
