// spiroLight.bas • draws HyperCycloids with one endPoint constrained
// pBasic Demo by John Roland Penner • April 14, 2026
// generates light beams with inner radial symmetry

var cx : Float = 630.0
var cy : Float = 500.0
var R  : Float = 200.0
var r  : Float = 75.0
var d  : Float = 120.0
var t  : Float = 0.0
var x  : Float = 0.0
var y  : Float = 0.0
var prevX : Float = 0.0
var prevY : Float = 0.0

// mouseButton state
var mb : Float = MOUSEAT(B)

// Beam Origin
var X : Float = 1024.0
var Y : Float = 0.0
var running : Bool = 1

// Pen Size
pen 2.0
clr
cls
locate 1,1
print "spiroLight"


timer 0.125 bunchOfSpiros()

// starting shot
fireSpiros()
timeron

while (running == 1) {
}

locate 1,1
print "shine on   "
end


// run a full cycle
func bunchOfSpiros() {
    
    var h$ = inkey$
    if h$ == " " then fireSpiros()
    if h$ == "DEL" then CLR
    if h$ == "ESC" then running = 0
    
    mb = MOUSEAT(B)
    if (mb > 1.0) then CLR
    if (mb > 0.0) then fireSpiros()
    
    return 0
}


func fireSpiros() {
	
	X = MOUSEAT(X)
	Y = MOUSEAT(Y)
	
    for n2 = 1 to 5
        R = rnd(1) * 300 + 150
        spiro()
        r = rnd(1) * 300 + 20 
        spiro()
        d = rnd(1) * 300 + 110
        spiro()
        t = rnd(1) * 300 + 10
        spiro()
    next n2

    return 0
}


func spiro() {
    var RR : Float = RND(1)
    var GG : Float = RND(1)
    var BB : Float = RND(1)
    
    prevX = X
    prevY = Y
    
    FOR t = 0 TO 128 STEP 0.50
        x = (R - r) * COS(t) + d * COS((R - r) * t / r) + cx
        y = (R - r) * SIN(t) - d * SIN((R - r) * t / r) + cy
        var AA : Float = 1.0 - (RND(1) * 0.4)
        line(prevX, prevY, x, y, RR, GG, BB, AA)
    NEXT t
    
    RETURN 0
}
