print "-- while test ----- "
var A = 5
var sum = 0
while (A < 20) {
	print "A equals "; 
	print A
	sum = sum + A
	A = A + 1
}
print "Sum is "; 
print sum
