// asteroids.bas ©2026 by John Roland Penner
// pBasic 0.8.30 — Milestone 30
// 
// Classic Asteroids: ship, bullets, meteors, collision detection
// Controls:
//   Arrow Left/Right : Rotate ship 22.5°
//   Up Arrow         : Thrust
//   Down Arrow       : Halt
//   Space            : Fire bullet
//   ESC              : Quit
// 
// IMPORTANT TIMER EXECUTOR RULES: 
//   1. All variables used in Timer-called functions must be declared Globally. 
//   2. Functions called from the Timer cannot use parameters — use Globals. 
//   3. You will need to account for Re-Entry of Timer code and Race Conditions. 
// 		An Interpreter can only do so much per millisecond -- so pack you 
//		Timer based function calls carefully. 


// ── Canvas bounds ─────────────────────────────────────────────────────────────
var xMin : Float = 0.0
var xMax : Float = 1260.0
var yMin : Float = 0.0
var yMax : Float = 1000.0

// ── Ship state ────────────────────────────────────────────────────────────────
var shipX   : Float = 630.0
var shipY   : Float = 500.0
var shipRot : Float = 0.0
var velX    : Float = 0.0
var velY    : Float = 0.0
var thrust  : Float = 0.0

// ── Scratch globals ───────────────────────────────────────────────────────────
var tx   : Float = 0.0
var ty   : Float = 0.0
var spd  : Float = 0.0
var bvx  : Float = 0.0
var bvy  : Float = 0.0
var bsx  : Float = 0.0
var bsy  : Float = 0.0
var ddist : Float = 0.0
var dx   : Float = 0.0
var dy   : Float = 0.0
var mang : Float = 0.0
var mi   : Int   = 0

// ── Bullet pool (sprites ID 10-13) ───────────────────────────────────────────
var b0x  : Float = 0.0
var b0y  : Float = 0.0
var b0vx : Float = 0.0
var b0vy : Float = 0.0
var b0on : Int   = 0

var b1x  : Float = 0.0
var b1y  : Float = 0.0
var b1vx : Float = 0.0
var b1vy : Float = 0.0
var b1on : Int   = 0

var b2x  : Float = 0.0
var b2y  : Float = 0.0
var b2vx : Float = 0.0
var b2vy : Float = 0.0
var b2on : Int   = 0

var b3x  : Float = 0.0
var b3y  : Float = 0.0
var b3vx : Float = 0.0
var b3vy : Float = 0.0
var b3on : Int   = 0

var bulletSlot : Int = 0

// ── Meteor arrays (Eight meteors, sprite IDs 20-27) ──────────────────────────────
var eight       : Int = 8
var meteorID[8] : Int
var mx[8]       : Float
var my[8]       : Float
var mvx[8]      : Float
var mvy[8]      : Float
var mon[8]      : Int
var mmRot       : Float = 0.0

// ── Physics ───────────────────────────────────────────────────────────────────
var thrustPower : Float = 2.0
var thrustDecay : Float = 0.9375
var bulletSpeed : Float = 18.0
var rotStep     : Float = 22.5
var maxSpeed    : Float = 10.0
var meteorSpeed : Float = 2.5
var degToRad    : Float = 0.01745329
var twoPi       : Float = 6.2831853

// ── Collision threshold (ship+meteor radii combined) ──────────────────────────
var shipHitDist   : Float = 75.0
var bulletHitDist : Float = 40.0


// ── Game state ────────────────────────────────────────────────────────────────
var running   : Int    = 1
var shipAlive : Int    = 1
var k$        : String = ""

// ── Declare ship and bullet sprites ──────────────────────────────────────────
//SPRITE(1,  630.0, 500.0, 0, 0.5, 1, 1.0, "@⧋")
SPRITE(1,  630.0, 500.0, 0, 1.0, 1, 1.0, "Demos/viperOn.png")
SPRITE(10, 0.0, 0.0, 0, 0.4, 0, 1.0, "@•")
SPRITE(11, 0.0, 0.0, 0, 0.4, 0, 1.0, "@•")
SPRITE(12, 0.0, 0.0, 0, 0.4, 0, 1.0, "@•")
SPRITE(13, 0.0, 0.0, 0, 0.4, 0, 1.0, "@•")
PLAY(1, 1.0, "Demos/Laser.wav")
PLAY(2, 1.0, "Demos/Roundoff.aif")
PLAY(3, 1.0, "Demos/Hit.wav")

// ── Initialise Eight meteor sprites ─────────────────────────────────────────────
mi = 0
while (mi < eight) {
    meteorID[mi] = 20 + mi
    mx[mi] = RND(0) * xMax
    my[mi] = RND(0) * yMax
    mang = RND(0) * twoPi
    mvx[mi] = COS(mang) * meteorSpeed
    mvy[mi] = SIN(mang) * meteorSpeed
    mon[mi] = 1
    SPRITE(meteorID[mi], mx[mi],my[mi], 0, 0.4 ,1 ,1.0, "@🪨")
    mi = mi + 1
}

cls
print "ASTEROIDS    ▲ Thrust  ◄ ► Rotate  Space=Fire  ESC=Quit "

// ─────────────────────────────────────────────────────────────────────────────
// GAME LOOP  (depth 0)
// ─────────────────────────────────────────────────────────────────────────────
func gameLoop() {

	while (running == 1) {
	    k$ = INKEY$
		
	    if k$ == "ESC" then running = 0
	    if k$ == "^L"  then shipRot = shipRot - rotStep
	    if k$ == "^R"  then shipRot = shipRot + rotStep
	
	    if shipRot < 0.0    then shipRot = shipRot + 360.0
	    if shipRot >= 360.0 then shipRot = shipRot - 360.0
		
	    if k$ == "^U" then thrust = thrust + thrustPower
	    if k$ == " " then spawnBullet()
	    if k$ == " " then PLAY(1)
		
		if k$ == "^D" then thrust = 0.0
		
	    tx = SIN(shipRot * degToRad) * thrust
	    ty = - COS(shipRot * degToRad) * thrust
	    velX = velX + tx * 0.1
	    velY = velY + ty * 0.1
		
	    spd = SQRT(velX * velX + velY * velY)
	    if spd > maxSpeed then velX = velX * maxSpeed / spd
	    if spd > maxSpeed then velY = velY * maxSpeed / spd
	
	    thrust = thrust * thrustDecay
	    if thrust < 0.1 then thrust = 0.0
		
		if k$ == "^D" then velX = 0.0
		if k$ == "^D" then velY = 0.0
		
	    shipX = shipX + velX
	    shipY = shipY + velY
	
	    if shipX < xMin then shipX = xMax
	    if shipX > xMax then shipX = xMin
	    if shipY < yMin then shipY = yMax
	    if shipY > yMax then shipY = yMin
	
	    if shipAlive == 1 then SPRITE(1, shipX, shipY, shipRot, , , , )
	
	    updateBullets()
	    updateMeteors()
	    checkShipCollision()
	
	    if running == 0 then timeroff
	}
	
	return 0
}

// ─────────────────────────────────────────────────────────────────────────────
// SPAWN BULLET  (depth 1, no further calls)
// ─────────────────────────────────────────────────────────────────────────────
func spawnBullet() {
    bvx = velX + SIN(shipRot * degToRad) * bulletSpeed
    bvy = velY - COS(shipRot * degToRad) * bulletSpeed
    bsx = shipX + SIN(shipRot * degToRad) * 30.0
    bsy = shipY - COS(shipRot * degToRad) * 30.0
	
	if bulletSlot == 0 {
		b0x  = bsx
	    b0y  = bsy
	    b0vx = bvx
	    b0vy = bvy
	    b0on = 1
	    SPRITE(10, bsx, bsy, 0, , 1, 1.0, )
		}

    if bulletSlot == 1 {
		b1x  = bsx
    	b1y  = bsy
    	b1vx = bvx
    	b1vy = bvy
    	b1on = 1
    	SPRITE(11, bsx, bsy, 0, , 1, 1.0, )
		}

    if bulletSlot == 2 {
		b2x  = bsx
    	b2y  = bsy
    	b2vx = bvx
    	b2vy = bvy
    	b2on = 1
    	SPRITE(12, bsx, bsy, 0, , 1, 1.0, )
		}

    if bulletSlot == 3 {
		b3x  = bsx
    	b3y  = bsy
    	b3vx = bvx
    	b3vy = bvy
    	b3on = 1
    	SPRITE(13, bsx, bsy, 0, , 1, 1.0, )
		}
	
    bulletSlot = bulletSlot + 1
    if bulletSlot > 3 then bulletSlot = 0
    
    return 0
}

// ─────────────────────────────────────────────────────────────────────────────
// UPDATE BULLETS  (depth 1)
// Each bullet: move, edge check, meteor collision — all inlined at depth 2.
// distance() is inlined as dx/dy/dist — no extra function call depth.
// ─────────────────────────────────────────────────────────────────────────────
func updateBullets() {
    if b0on == 1 then moveBullet0()
    if b1on == 1 then moveBullet1()
    if b2on == 1 then moveBullet2()
    if b3on == 1 then moveBullet3()
    return 0
}

// Bullet 0 — depth 2: move + edge + all meteor collision checks inlined
func moveBullet0() {
    b0x = b0x + b0vx
    b0y = b0y + b0vy
    if b0x < xMin then b0on = 0
    if b0x > xMax then b0on = 0
    if b0y < yMin then b0on = 0
    if b0y > yMax then b0on = 0
    if b0on == 0 then SPRITE(10, , , , , 0, , )
    if b0on == 1 then SPRITE(10, b0x, b0y, , , , , )
    // Check vs all meteors — distance inlined
    mi = 0
    while (mi < eight) {
        if mon[mi] == 1 then checkB0M()
        mi = mi + 1
    }
    return 0
}

func checkB0M() {
	ddist = dist(b0x, b0y, mx[mi], my[mi])
    if ddist < bulletHitDist {
		mon[mi] = 0
    	SPRITE(meteorID[mi], , , , , 0, , )
    	b0on = 0
    	SPRITE(10, , , , , 0, , )
		PLAY(3)
	}
	return 0
}

// Bullet 1
func moveBullet1() {
    b1x = b1x + b1vx
    b1y = b1y + b1vy
    if b1x < xMin then b1on = 0
    if b1x > xMax then b1on = 0
    if b1y < yMin then b1on = 0
    if b1y > yMax then b1on = 0
    if b1on == 0 then SPRITE(11, , , , , 0, , )
    if b1on == 1 then SPRITE(11, b1x, b1y, , , , , )
    mi = 0
    while (mi < eight) {
        if mon[mi] == 1 then checkB1M()
        mi = mi + 1
    }
    return 0
}

func checkB1M() {
	ddist = dist(b1x, b1y, mx[mi], my[mi])
    if ddist < bulletHitDist {
		mon[mi] = 0
    	SPRITE(meteorID[mi], , , , , 0, , )
    	b1on = 0
    	SPRITE(11, , , , , 0, , )
		PLAY(3)
	}
	return 0
}

// Bullet 2
func moveBullet2() {
    b2x = b2x + b2vx
    b2y = b2y + b2vy
    if b2x < xMin then b2on = 0
    if b2x > xMax then b2on = 0
    if b2y < yMin then b2on = 0
    if b2y > yMax then b2on = 0
    if b2on == 0 then SPRITE(12, , , , , 0, , )
    if b2on == 1 then SPRITE(12, b2x, b2y, , , , , )
    mi = 0
    while (mi < eight) {
        if mon[mi] == 1 then checkB2M()
        mi = mi + 1
    }
    return 0
}

func checkB2M() {
    //dx = b2x - mx[mi]
    //dy = b2y - my[mi]
    //ddist = SQRT(dx * dx + dy * dy)
    ddist = dist(b2x, b2y, mx[mi], my[mi])
	if ddist < bulletHitDist {
		mon[mi] = 0
    	SPRITE(meteorID[mi], , , , , 0, , )
    	b2on = 0
    	SPRITE(12, , , , , 0, , )
		PLAY(3)
	}
	return 0
}

// Bullet 3
func moveBullet3() {
    b3x = b3x + b3vx
    b3y = b3y + b3vy
    if b3x < xMin then b3on = 0
    if b3x > xMax then b3on = 0
    if b3y < yMin then b3on = 0
    if b3y > yMax then b3on = 0
    if b3on == 0 then SPRITE(13, , , , , 0, , )
    if b3on == 1 then SPRITE(13, b3x, b3y, , , , , )
    mi = 0
    while (mi < eight) {
        if mon[mi] == 1 then checkB3M()
        mi = mi + 1
    }
    return 0
}

func checkB3M() {
    //dx = b3x - mx[mi]
    //dy = b3y - my[mi]
    //ddist = SQRT(dx * dx + dy * dy)
	ddist = dist(b3x, b3y, mx[mi], my[mi])
    if ddist < bulletHitDist {
		mon[mi] = 0
    	SPRITE(meteorID[mi], , , , , 0, , )
    	b3on = 0
    	SPRITE(13, , , , , 0, , )
		PLAY(3)
	}
	return 0
}

// ─────────────────────────────────────────────────────────────────────────────
// UPDATE METEORS  (depth 1 → depth 2: moveMeteorMi)
// ─────────────────────────────────────────────────────────────────────────────
func updateMeteors() {
	var allGone : Int = eight
	mi = 0
	while (mi < eight) {
		if mon[mi] == 0 then allGone = allGone - 1
		if mon[mi] == 1 then moveMeteorMi()
		mi = mi + 1
	}
	if allGone == 0 {
		locate 10, 30
		fill(0.3, 0, 0, 0.7)
		print "✨✨✨  LEVEL CLEARED ✨✨✨"
		fill(0, 0, 0, 0)
		running = 0
	}
	return 0
}

func moveMeteorMi() {
    mx[mi] = mx[mi] + mvx[mi]
    my[mi] = my[mi] + mvy[mi]
	
    if mx[mi] < xMin {
		mvx[mi] = ABS(mvx[mi])
		mx[mi] = xMin
		}
    if mx[mi] > xMax {
		mvx[mi] = 0.0 - ABS(mvx[mi])
		mx[mi] = xMax
		}
    if my[mi] < yMin {
		mvy[mi] = ABS(mvy[mi])
		my[mi] = yMin
		}
    if my[mi] > yMax {
		mvy[mi] = 0.0 - ABS(mvy[mi])
		my[mi] = yMax
		}

	mmRot = mmRot + 0.125
	if mmRot > 360 then mmRot = 0
	
    SPRITE(meteorID[mi], mx[mi], my[mi], mmRot, , , , )
    return 0
}

// ─────────────────────────────────────────────────────────────────────────────
// SHIP COLLISION  (depth 1 → depth 2: checkShipMi)
// distance inlined — no extra depth
// ─────────────────────────────────────────────────────────────────────────────
func checkShipCollision() {
    if shipAlive == 0 then return 0
    mi = 0
    while (mi < eight) {
        if mon[mi] == 1 then checkShipMi()
        mi = mi + 1
    }
    return 0
}

func checkShipMi() {
    ddist = dist(shipX, shipY, mx[mi], my[mi])
	if ddist < shipHitDist then shipHit()
	return 0
}

func shipHit() {
    shipAlive = 0
	//SPRITE(id, x, y, rotation, scale, hidden, alpha, imageURL)
    //SPRITE(1, , , , , 0, , )
	SPRITE(1, , , ,2.5 , 1, 0.25 , )
	PLAY(2)
    locate 10, 30
	fill(0.3, 0, 0, 0.7)
    print "✨✨✨  SHIP DESTROYED ✨✨✨"
    locate 11, 30
	fill(0, 0, 0, 0)
    print "    Press ESC to Quit   "
    return 0
}

// ─────────────────────────────────────────────────────────────────────────────
// START
// ─────────────────────────────────────────────────────────────────────────────
timer 0.025 gameLoop
timeron

while (running == 1) {
}

print ""
print "Game Over! "
SPRITE(1, , , ,2.5 , 0, 0.45 , )
meow
end
