// clockey.bas
print "pBasic Digital Clock"
TIMER 0.25 showClock
TIMERON

cls
clr
pen 4
fill(0,1,0,0.2)
roundrect(480, 320, 770, 500, 20)	// 500-320=180 * ɸ = 290
fill(0,0,0,0)

// Global Variables
var running : Int = 1
var meep : Int = 0
var k$ : String = ""

// Cookoo Clock Variables
var t$ : String = time
var m : Float = 0
var s : Float = 0
var isSpeaking : Bool = 0

while (running == 1) {
	
	// global variable incremented in TIMER
	if meep > 100 then meep = 0
	
	// Speak Time on the Hour
	t$ = time
    m = VAL(MID$(t$, 3, 2))
    s = VAL(MID$(t$, 6, 2))
    
    if (s > 4) then isSpeaking = 0
    if (s == 0 && isSpeaking == 0) then meow
    if (s+m == 0 && isSpeaking == 0) { 
    	isSpeaking = 1
    	say time
    }
	
}

print ""
print "meep meep " + STR$(meep)

//input "type Enter to quit "; A$
//print "Thank you ";
//print A$

end

func showClock() {
	locate 9,35
	print time
			
    k$ = INKEY$
    locate 11, 35
    if k$ == "^U" then print "Up Arrow    ";
    if k$ == "^D" then print "Down Arrow  ";
    if k$ == "^L" then print "Left Arrow  ";
    if k$ == "^R" then print "Right Arrow ";
    if k$ == "RET" then print "Return key ";
    if k$ == "DEL" then print "Delete key ";
    if k$ == " " then print   "Space key  ";
    if k$ == "ESC" then running = 0
    
    meep = meep + 1
	return 0
}
