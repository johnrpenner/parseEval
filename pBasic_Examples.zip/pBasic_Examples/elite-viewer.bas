// ================================================
// ELITE 3D Model Viewer • pBasic v0.8.55
// Loads 3D wireframe models from .txt files
// ================================================

// Up/Down arrows: add X-axis spin
// Left/Right arrows: add Y-axis spin
// Rotations accumulate and combine freely
// ESC or CTRL-C to quit

clr
cls

//var modelFile$ : String = "Demos/elite-viper.txt"
//var modelFile$ : String = "Demos/elite-cobraMK3.txt"
var modelFile$ : String = "Demos/elite-mamba.txt"
//var modelFile$ : String = "Demos/elite-coriolis.txt"
//var modelFile$ : String = "Demos/elite-thargoid.txt"

// Arrays
var vx[50] : Float
var vy[50] : Float
var vz[50] : Float
var edgeStart[100] : Int
var edgeEnd[100] : Int

var numVertices : Int = 0
var numEdges : Int = 0
var modelName$ : String = ""

// Camera / Rotation
var rotY : Float = 0.0
var rotX : Float = -0.3
var spinY : Float = 0.03
var spinX : Float = 0.0

var zoom : Float = 5.5
var dist : Float = 280.0
var cx   : Float = 630.0
var cy   : Float = 480.0

// Working variables
var psx[50] : Float
var psy[50] : Float
var cosY : Float = 0.0
var sinY : Float = 0.0
var cosX : Float = 0.0
var sinX : Float = 0.0
var frame : Int = 0
var running : Int = 1
var k$ : String = ""

var lines[500] : String
var result$[50] : String


// ─────────────────────────────────────────────
// Load Model
// ─────────────────────────────────────────────
loadModel(modelFile$)

print "Elite 3D Model Viewer"
print "Controls: Arrow keys to rotate | ESC to quit"
print "Loaded: " + modelName$ + " • Vertices: " + STR$(numVertices) + " • Edges: " + STR$(numEdges)
print ""

BUFFER

while (running == 1) {
    k$ = INKEY$
    
    if k$ == "ESC" then running = 0
    if k$ == "^U" then spinX = spinX - 0.01
    if k$ == "^D" then spinX = spinX + 0.01
    if k$ == "^L" then spinY = spinY - 0.01
    if k$ == "^R" then spinY = spinY + 0.01
    
    // Round to 4 decimal places to kill floating point drift
    spinX = INT(spinX * 10000.0 + 0.5) / 10000.0
    spinY = INT(spinY * 10000.0 + 0.5) / 10000.0

    // Clamp runaway values
    if spinY > 100.0 then spinY = 0.0
    if spinY < -100.0 then spinY = 0.0
    if spinX > 100.0 then spinX = 0.0
    if spinX < -100.0 then spinX = 0.0
    
    LOCATE 1, 60
    print "SpinX: "; 
    print spinX;
    print "    "
    LOCATE 2, 60
    print "SpinY: ";
    print spinY;
    print "    ";
	
    cosY = COS(rotY)
    sinY = SIN(rotY)
    cosX = COS(rotX)
    sinX = SIN(rotX)

    // Project vertices
    var i : Int = 0
    while (i < numVertices) {
        var prx : Float = vx[i] * cosY - vz[i] * sinY
        var prz : Float = vx[i] * sinY + vz[i] * cosY
        var pry : Float = vy[i] * cosX - prz * sinX
        var prz2 : Float = vy[i] * sinX + prz * cosX
        var pw : Float = dist / (dist + prz2 + 80.0)
        
        psx[i] = cx + prx * zoom * pw
        psy[i] = cy - pry * zoom * pw
        i = i + 1
    }

    CLR

    // Draw edges
    i = 0
    while (i < numEdges) {
        var a : Int = edgeStart[i]
        var b : Int = edgeEnd[i]
        LINE(psx[a], psy[a], psx[b], psy[b], 0.9, 0.85, 0.5, 1.0)
        i = i + 1
    }

    // Draw vertices
    PEN 4.0
    i = 0
    while (i < numVertices) {
        POINT(psx[i], psy[i], 0.4, 0.85, 1.0, 1.0)
        i = i + 1
    }
    PEN 1.8

    BUFFER

    rotY = rotY + spinY
    rotX = rotX + spinX
    frame = frame + 1
}

fill(0.0, 0.0, 0.0, 0.0)
print " "
end


// ================================================
// Load Model from File
// ================================================
func loadModel(filename$) {
    lines[] = LOAD(filename$)
    var lineCount = LEN(lines[])
        
    var wc : Int = 0
    var ww : String = ""
	var cmd$ : String = ""
    var i : Int = 0
    var vIdx : Int = 0
    var eIdx : Int = 0
    var lline$ : String = ""
    
    while (i < lineCount) {
        lline$ = lines[i]
        
        // Skip empty lines and comments
        if ( LEN(lline$) > 0 && MID$(lline$, 0, 2) <> "//" ) {
        	
            wc = getWords(lline$)
            ww = result$[0]
            
            if (wc > 0) {
                cmd$ = ww
                
                if (cmd$ == "o" && wc >= 3) {
                    numVertices = VAL(result$[1])
                    numEdges = VAL(result$[2])
                    modelName$ = result$[3]
                }
                if (cmd$ == "v" && wc >= 3) {
                    vx[vIdx] = VAL(result$[1])
                    vy[vIdx] = VAL(result$[2])
                    vz[vIdx] = VAL(result$[3])
                    vIdx = vIdx + 1
                }
                if (cmd$ == "e" && wc >= 2) {
                    edgeStart[eIdx] = VAL(result$[1])
                    edgeEnd[eIdx] = VAL(result$[2])
                    eIdx = eIdx + 1
                }
            }
        }
        i = i + 1
    }
    return 0
}


// ================================================
// Split string into words (space separated)
// returns result$[count] -- must declare Globally
// ================================================
func getWords(a$) {
	//var result$[150] : String
    var lineLen : Int = LEN(a$)
    var index : Int = 0
    var start : Int = 0
    var count : Int = 0
    var inWord : Int = 0
    var ch$ : String = MID$(a$, index, 1)
    
    while (index <= lineLen) {
        ch$ = MID$(a$, index, 1)
        
        if (ch$ <> " " && ch$ <> "" && inWord == 0) {
            start = index
            inWord = 1
        }
        
        if ((ch$ == " " || index == lineLen) && inWord == 1) {
            result$[count] = MID$(a$, start, index - start)
            count = count + 1
            inWord = 0
        }
        
        index = index + 1
    }
    
    return count-1
}
