// fileSortTest.bas
// four-sort benchmark: interpreted vs native, alpha vs length
// Outputs four files and timing for each sort pass. 

var fileLines[50001]  : String
var sortedLines[50001] : String
var lineCount : Int = 0
var a$ : String = ""
var base$ : String = ""
var outA$ : String = ""
var outB$ : String = ""
var outC$ : String = ""
var outD$ : String = ""
var t1$ : String = ""
var t2$ : String = ""
var sortJ : Int = 0
var sortKey$ : String = ""
var sortKeyLen : Int = 0
var sortScanning : Int = 0
var sortInsertAt : Int = 0
var i : Int = 0
var milestone : Int = 0

input "Enter filename: "; a$
if a$ == "" then end

// Strip .txt extension for base name if present
base$ = a$
if MID$(a$, LEN(a$) - 3, 4) == ".txt" then base$ = MID$(a$, 0, LEN(a$) - 4)

outA$ = base$ + "-i-alphaInterpreted.txt"
outB$ = base$ + "-ii-lenInterpreted.txt"
outC$ = base$ + "-iii-alphaNative.txt"
outD$ = base$ + "-iv-lenNative.txt"

// ── Load source file ──────────────────────────────────────────────
fileLines[] = LOAD(a$)
doCountLines()
print "Loaded "; 
print lineCount; 
print " lines from "; 
print a$
print ""

// ── Pass i: interpreted alphabetical sort ────────────────────────
print "Pass i  — interpreted alpha sort..."
t1$ = TIME
doAlphaSort()
t2$ = TIME
SAVE outA$, fileLines[]
print "  Start : " + t1$
print "  End   : " + t2$
print "  Saved : " + outA$
print ""

// ── Reload source for pass ii ─────────────────────────────────────
fileLines[] = LOAD(a$)

// ── Pass ii: interpreted length sort ─────────────────────────────
print "Pass ii — interpreted length sort..."
t1$ = TIME
doLenSort()
t2$ = TIME
SAVE outB$, fileLines[]
print "  Start : " + t1$
print "  End   : " + t2$
print "  Saved : " + outB$
print ""

// ── Reload source for pass iii ────────────────────────────────────
fileLines[] = LOAD(a$)

// ── Pass iii: native alphabetical sort ───────────────────────────
print "Pass iii — native alpha sort..."
t1$ = TIME
SORT fileLines[]
t2$ = TIME
SAVE outC$, fileLines[]
print "  Start : " + t1$
print "  End   : " + t2$
print "  Saved : " + outC$
print ""

// ── Reload source for pass iv ─────────────────────────────────────
fileLines[] = LOAD(a$)

// ── Pass iv: native length sort ──────────────────────────────────
print "Pass iv — native length sort..."
t1$ = TIME
SORTLEN fileLines[]
t2$ = TIME
SAVE outD$, fileLines[]
print "  Start : " + t1$
print "  End   : " + t2$
print "  Saved : " + outD$
print ""

print "All done. " + STR$(lineCount) + " lines sorted four ways."
end

// ── Interpreted insertion sort: alphabetical ──────────────────────
func doAlphaSort() {
    var ai : Int = 0
    for ai = 1 to lineCount - 1
        sortKey$ = fileLines[ai]
        sortJ = ai - 1
        sortInsertAt = ai
        sortScanning = 1
        while (sortScanning == 1) {
            doAlphaInnerStep()
        }
        fileLines[sortInsertAt] = sortKey$
        milestone = int(ai / 500) * 500
        if milestone == ai then printProgress(ai)
    next ai
    return 0
}

func doAlphaInnerStep() {
    if fileLines[sortJ] <= sortKey$ then doStopScan()
    if sortScanning == 1 then fileLines[sortJ + 1] = fileLines[sortJ]
    if sortScanning == 1 then sortInsertAt = sortJ
    if sortScanning == 1 then sortJ = sortJ - 1
    if sortJ < 0 then doStopScan()
    return 0
}

// ── Interpreted insertion sort: by length ────────────────────────
func doLenSort() {
    var li : Int = 0
    for li = 1 to lineCount - 1
        sortKey$ = fileLines[li]
        sortKeyLen = len(sortKey$)
        sortJ = li - 1
        sortInsertAt = li
        sortScanning = 1
        while (sortScanning == 1) {
            doLenInnerStep()
        }
        fileLines[sortInsertAt] = sortKey$
        milestone = int(li / 500) * 500
        if milestone == li then printProgress(li)
    next li
    return 0
}

func doLenInnerStep() {
    if len(fileLines[sortJ]) <= sortKeyLen then doStopScan()
    if sortScanning == 1 then fileLines[sortJ + 1] = fileLines[sortJ]
    if sortScanning == 1 then sortInsertAt = sortJ
    if sortScanning == 1 then sortJ = sortJ - 1
    if sortJ < 0 then doStopScan()
    return 0
}

func doStopScan() {
    sortScanning = 0
    return 0
}

func doCountLines() {
    lineCount = 0
    while (fileLines[lineCount] <> "") {
        lineCount = lineCount + 1
    }
    return 0
}

func printProgress(i) {
    print "  Sorting: ";
    print i;
    print " of ";
    print lineCount
    return 0
}
