// Julia fractal   K Moerman 2026
// shamelessly adapted by UglyMike the day after

// ================================================
// JULIA SET EXPLORER - pBasic v0.8.54
// Clean version - No ELSE, No CALL
// ================================================

clr
cls

print "Julia Set Explorer"
print "Move mouse to explore"
print "Click to render full set"
print "ESC to exit"
print ""

var w : Int = 800
var h : Int = 800
var N : Int = 120
var hw : Float = w / 2.0
var hh : Float = h / 2.0

var r[120] : Float
var g[120] : Float
var b[120] : Float

var mx : Float = 0.0
var my : Float = 0.0
var mb : Float = 0.0
var old_mx : Float = -1.0
var old_my : Float = -1.0
var running : Int = 1

calccolors()

while (running == 1) {
    mx = MOUSEAT(X)
    my = MOUSEAT(Y)
    mb = MOUSEAT(B)
    
    if (mx <> old_mx || my <> old_my) {
        BUFFER
        CLR
        fill(0.0, 0.0, 0.0, 1.0)
        
        var Cre : Float = (mx / w) * -2.0 + 1.5
        var Cim : Float = (my / h) * -2.5 + 1.25
        
        var x : Float = Cre
        var yi : Float = Cim
        var cx : Float = x
        var cyi : Float = yi
        
        locate 2,70
        print str$(Cre) + str$(Cim) + "  ";
        
        for ij = 1 to 1200
            cx = cx + x
            cyi = cyi - yi
            
            var ncx : Float = 0.0
            var ncyi : Float = 0.0
            
            if (cx > 0.0) {
                ncx = ((cx + (cx*cx + cyi*cyi)^0.5) / 2.0)^0.5
                ncyi = cyi / (2.0 * ncx)
            }
            if (cx < 0.0) {
                ncyi = ((-cx + (cx*cx + cyi*cyi)^0.5) / 2.0)^0.5
                ncx = cyi / (2.0 * ncyi)
            }
            if (cx == 0.0) {
                ncx = (ABS(cyi)/2.0)^0.5
                if (ncx > 0.0) then ncyi = cyi / (2.0 * ncx)
            }
            
            if (RND(0) > 0.5) {
                cx = ncx
                cyi = ncyi
            }
            if (RND(0) <= 0.5) {
                cx = -ncx
                cyi = -ncyi
            }
            
            POINT(cx*180 + hw, cyi*180 + hh, 1.0, 1.0, 1.0, 1.0)
        next ij
        
        LOCATE 1, 2
        print "Move mouse | Click for full render"
        
        BUFFER
        old_mx = mx
        old_my = my
    }
    
    if (mb > 0.0) {
        renderFullJulia(Cre, Cim)
        while (mb > 0.0) { 
        	mb = MOUSEAT(B)
        }
    }
    
    var k$ : String = INKEY$
    if k$ == "ESC" then running = 0
}

mx = MOUSEAT(X)
my = MOUSEAT(Y)
Cre = (mx / w) * -2.0 + 1.5
Cim = (my / h) * -2.5 + 1.25
renderFullJulia(Cre, Cim)

fill(0.0, 0.0, 0.0, 0.0)
print ""
print "Goodbye!"
end


// ================================================
// Full Julia Renderer
// ================================================
func renderFullJulia(Cre, Cim) {
	CLR
    BUFFER
    CLR
    fill(0.0, 0.0, 0.0, 1.0)
    meow
    
    var x : Float = 0
    var y : Float = 0
    var zx : Float = 0.0
    var zy : Float = 0.0
    var c : Float = 0
    var zre_sq : Float = 0.0
    var zim_sq : Float = 0.0
    var next_zy : Float = 0.0
    
    for x = 0 to 799
        for y = 0 to 799
            zx = (hw - x) / 180.0
            zy = (hh - y) / 180.0
            c = 0
            
            while (c < N-2) {
                zre_sq = zx * zx
                zim_sq = zy * zy
                next_zy = 2.0 * zx * zy + Cim
                zx = zre_sq - zim_sq - Cre
                zy = next_zy
                c = c + 1
                if (zre_sq + zim_sq > 4.0) {
                	break
                }
            }
            
            if (c >= N-2) {
                POINT(x, y, 0.0, 0.0, 0.0, 1.0)
            }
            if (c < N-2) {
                //POINT(x, y, r[c]/255.0, g[c]/255.0, b[c]/255.0, 1.0)
                POINT(x, y, r[c], g[c], b[c], 1.0)
            }
        next y
        
        if (x % 30 == 0) { 
        	BUFFER
        	}
    next x
    
    LOCATE 1, 2
    print "Full Julia Set - Click to return"
    
    BUFFER
    return 0
}


// ================================================
// Colour Palette
// ================================================
func calccolors() {
    var k : Int = 0
    var c : Float = 0.0
    
    for k = 0 to N-1
        //c = 255.0 * SQR(k) / SQR(N)
        c = SQR(k) / SQR(N)
        r[k] = (c % 32) * 8
        g[k] = (c % 128) * 2
        b[k] = (c % 64) * 4
    next k
    return 0
}
