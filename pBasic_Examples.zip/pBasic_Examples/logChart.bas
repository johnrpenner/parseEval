// logchart.bas
// Log Scale Chart Demo for pBasic
// Mode 1: Manual input 
// Mode 2: Auto random every 0.5 seconds

CLS
print "Log Scale Chart Demo"
print "Press M for Manual Input Mode"
print "Press A for Auto Random Mode"
print "ESC to quit"

var mode : String = ""
var k$   : String = ""

while (mode == "") {
    k$ = INKEY$
    if k$ == "M" || k$ == "m" then mode = "manual"
    if k$ == "A" || k$ == "a" then mode = "auto"
    if k$ == "ESC" then mode = "quit"
}

if (mode == "quit") {
    print "Goodbye!"
    end
}

// ── Chart setup ─────────────────────────────────────────────────────────────
var data[500] : Float
var count     : Int = 0

var running : Int = 1

if (mode == "auto") {
    TIMER 0.5 addRandomValue
    TIMERON
}

while (running == 1) {
    k$ = INKEY$
    if k$ == "ESC" then running = 0

    if (mode == "manual") {
        manualInput()
    }

    drawLogChart()
    BUFFER
}

TIMEROFF
print ""
print "Goodbye!"
end

// ── Manual Input ────────────────────────────────────────────────────────────
func manualInput() {
    print "Enter value (-100 to 100) or ESC: ";
    var inputStr : String = INPUT$()

    if (inputStr == "ESC" || inputStr == "esc") {
        running = 0
        return 0
    }

    var val : Float = VAL(inputStr)
    if val < -100.0 then val = -100.0
    if val > 100.0 then val = 100.0

    addDataPoint(val)
    return 0
}

// ── Auto Mode Callback ──────────────────────────────────────────────────────
func addRandomValue() {
    var val : Float = RND(1) * 200.0 - 100.0
    addDataPoint(val)
    return 0
}

// ── Add data point ──────────────────────────────────────────────────────────
func addDataPoint(val) {
    if count < 500 then count = count + 1

    var i : Int = 0
    for i = 0 to 498
        data[i] = data[i+1]
    next i

    data[count-1] = val
    return 0
}

// ── Draw Log Scale Chart ────────────────────────────────────────────────────
func drawLogChart() {
    CLR

    // Grid
    var i : Int = 0
    for i = -100 to 100 step 20
        var y : Float = 500.0 - i * 3.8
        LINE(100, y, 1160, y, 0.15, 0.15, 0.15, 1.0)
    next i

    LINE(100, 500, 1160, 500, 0.4, 0.4, 0.4, 1.0)

    if count < 2 then return 0

    var prevSX : Float = 0.0
    var prevSY : Float = 0.0

    for i = 0 to count-1
        var val : Float = data[i]

        var logVal : Float = 0.0
        if val > 0.0 then logVal = log10(1.0 + val)
        if val < 0.0 then logVal = -log10(1.0 + ABS(val))

        var sx : Float = 100.0 + i * (1060.0 / (count + 20))
        var sy : Float = 500.0 - logVal * 85.0

        if i > 0 then LINE(prevSX, prevSY, sx, sy, 0.9, 0.6, 0.2, 1.0)

        prevSX = sx
        prevSY = sy
    next i

    locate 1, 5
    print "Log Scale Chart  |  Range: -100 to +100"

    if (mode == "auto") {
        locate 2, 5
        print "AUTO RANDOM MODE"
    }
    if (mode == "manual") {
        locate 2, 5
        print "MANUAL INPUT MODE"
    }

    return 0
}
