// ================================================
// AMIGA-STYLE PLASMA EFFECT - pBasic v0.8.54
// Converted from GBASIC
// ================================================

clr
cls

PRINT "Amiga Plasma Effect"

var T : Float = 0.0
var k$ : String = ""
var running : Bool = 1

var c : Float = 0.0
var CC : Float = 0.0
var v1 : Float = 0.0
var v2 : Float = 0.0
var v3 : Float = 0.0

var RR : Float = 0.0
var GG : Float = 0.0
var BB : Float = 0.0

while (running == 1) {
    T = T + 0.1
    
	locate 1,1
    for y = 0 to 190 step 8
    	
    	k$ = INKEY$
    	if k$ == "ESC" then running = 0
    	
        for x = 0 to 620 step 8
            v1 = SIN(x / 50.0 + T)
            v2 = SIN(y / 30.0 - T)
            v3 = SIN((x + y) / 60.0 + T * 1.5)
            
            c = ((v1 + v2 + v3 + 3.0) * 42.0)
        	
            RR = c/255
            GG = 0.2
            BB = (1.0 - c)/255
            
            // Filled Rectangle (plasma cell) -> TEXT CELL " "
            FILL( RR, GG, BB, 0.7 )
            PRINT " ";
            //RECT(x, y, x+8, y+8)
            
        next x
        print ""
        
    next y
    buffer
    
}

fill(0,0,0,0)
print " "
print "babooshka! "

end
