// ptest_Array.bas
// pBasic v0.8.58 — Complete Validation Suite
// Tests all keywords, functions, and language features
// May 27, 2026

var grid[4,4] : Int
grid[0,0] = 1
grid[1,1] = 5
grid[2,2] = 9
grid[3,3] = 16
print grid[0,0]    // 1
print grid[1,1]    // 5
print grid[2,2]    // 9
print grid[3,3]    // 16

// ───────────────────────────────────────────────
// Section 58: Functions with Multi-Dimensional Arrays
// ───────────────────────────────────────────────
print "--- Section 58: Functions with Array[] Parameters ----- "
print ""

var testArr[5] : Int
print "about to call fillArray"
fillArray(testArr[], 5)
print testArr[0]   // 0
print testArr[4]   // 8

var gridTest[3,3] : Int
print "about to call fillGrid"
fillGrid(gridTest[], 3, 3)
print gridTest[0,0]   // 0
print gridTest[1,1]   // 4
print gridTest[2,2]   // 8

func fillArray(arr[], n) {
    for i = 0 to n-1
        arr[i] = i * 2
    next i
    return arr[]
}

func fillGrid(grid[], rows, cols) {
    for r = 0 to rows-1
        for c = 0 to cols-1
            grid[r,c] = r * cols + c
        next c
    next r
    return grid[]
}

print ""
print ""
