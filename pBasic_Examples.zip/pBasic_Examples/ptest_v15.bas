// ptest_v16.bas
// pBasic v0.8.58 — Complete Validation Suite
// Tests all keywords, functions, and language features
// May 27, 2026

clr
buffer 
clr
buffer
cls

print "============================================"
fill(0, 0.3, 0, 0.7)
print "  pBasic v0.8.58 — Complete Validation Suite"
fill(0, 0, 0, 0)
print "============================================"
print ""

// ─────────────────────────────────────────────
// Section 1: Variables & Types
// ─────────────────────────────────────────────
print "--- Section 1: Variables & Types ---"
var i : Int = 42
var f : Float = 3.14
var b : Bool = 1
var s$ : String = "hello"
print i
print f
print b
print s$
print ""

// ─────────────────────────────────────────────
// Section 2: Arithmetic
// ─────────────────────────────────────────────
print "--- Section 2: Arithmetic ---"
var a : Int = 10
var c : Int = 3
print a + c
print a - c
print a * c
print a / c
print a ^ 2
print ""

// ─────────────────────────────────────────────
// Section 3: Float Arithmetic
// ─────────────────────────────────────────────
print "--- Section 3: Float Arithmetic ---"
var x : Float = 10.5
var y : Float = 3.2
print x + y
print x - y
print x * y
print x / y
print ""

// ─────────────────────────────────────────────
// Section 4: Math Functions
// ─────────────────────────────────────────────
print "--- Section 4: Math Functions ---"
print SIN(0)
print COS(0)
print TAN(0)
print ATAN(1)
print SQRT(16)
print SQR(4)
print ABS(-7)
print INT(3.9)
print EXP(1)
print LOG(1)
print LOG10(100)
print ""

// ─────────────────────────────────────────────
// Section 5: Constants
// ─────────────────────────────────────────────
print "--- Section 5: Constants ---"
print PI
print DATE
print TIME
print ""

// ─────────────────────────────────────────────
// Section 6: String Operations
// ─────────────────────────────────────────────
print "--- Section 6: String Operations ---"
var s1$ : String = "Hello"
var s2$ : String = " World"
var s3$ : String = s1$ + s2$
print s3$
print LEN(s3$)
print MID$(s3$, 0, 5)
print MID$(s3$, 6, 5)
print ""

// ─────────────────────────────────────────────
// Section 7: Comparison Operators
// ─────────────────────────────────────────────
print "--- Section 7: Comparison Operators ---"
print 5 == 5
print 5 <> 6
print 5 > 3
print 5 < 3
print 5 >= 5
print 5 <= 4
print ""

// ─────────────────────────────────────────────
// Section 8: String Comparisons
// ─────────────────────────────────────────────
print "--- Section 8: String Comparisons ---"
var p$ : String = "apple"
var q$ : String = "apple"
var r$ : String = "banana"
print p$ == q$
print p$ == r$
print p$ <> r$
print ""

// ─────────────────────────────────────────────
// Section 9: IF THEN
// ─────────────────────────────────────────────
print "--- Section 9: IF THEN ---"
var n : Int = 7
if n > 5 then print "n greater than 5"
if n == 7 then print "n equals 7"
if n < 3 then print "ERROR: should not print"
if n <> 3 then print "n not equal to 3"
var chk$ : String = "yes"
if chk$ == "yes" then print "string IF passed"
print ""

// ─────────────────────────────────────────────
// Section 10: IF THEN assignment
// ─────────────────────────────────────────────
print "--- Section 10: IF THEN assignment ---"
var q2 : Int = 0
if n == 7 then q2 = 99
print q2
var t$ : String = ""
if chk$ == "yes" then t$ = "assigned"
print t$
print ""

// ─────────────────────────────────────────────
// Section 11: IF THEN func call
// ─────────────────────────────────────────────
print "--- Section 11: IF THEN func call ---"
if n == 7 then sayHello()
if n == 3 then sayHello()
print ""

// ─────────────────────────────────────────────
// Section 12: FOR NEXT
// ─────────────────────────────────────────────
print "--- Section 12: FOR NEXT ---"
var total : Int = 0
for j = 1 to 5
    total = total + j
next j
print total
print ""

// ─────────────────────────────────────────────
// Section 13: FOR NEXT with STEP
// ─────────────────────────────────────────────
print "--- Section 13: FOR NEXT STEP ---"
var countdown : Int = 0
for k = 10 to 1 step -1
    countdown = countdown + k
next k
print countdown
var fsum : Float = 0
for fv = 0.0 to 1.0 step 0.25
    fsum = fsum + fv
next fv
print fsum
print ""

// ─────────────────────────────────────────────
// Section 14: WHILE
// ─────────────────────────────────────────────
print "--- Section 14: WHILE ---"
var w : Int = 1
var wsum : Int = 0
while (w <= 5) {
    wsum = wsum + w
    w = w + 1
}
print wsum
print ""

// ─────────────────────────────────────────────
// Section 15: Nested WHILE
// ─────────────────────────────────────────────
print "--- Section 15: Nested WHILE ---"
var outer : Int = 1
var pairs : Int = 0
while (outer <= 3) {
    var inner : Int = 1
    while (inner <= 3) {
        pairs = pairs + 1
        inner = inner + 1
    }
    outer = outer + 1
}
print pairs
print ""

// ─────────────────────────────────────────────
// Section 16: Arrays
// ─────────────────────────────────────────────
print "--- Section 16: Arrays ---"
var arr[5] : Int
arr[0] = 10
arr[1] = 20
arr[2] = 30
arr[3] = 40
arr[4] = 50
print arr[0]
print arr[2]
print arr[4]
var asum : Int = 0
for ai = 0 to 4
    asum = asum + arr[ai]
next ai
print asum
print ""

// ─────────────────────────────────────────────
// Section 17: String Arrays
// ─────────────────────────────────────────────
print "--- Section 17: String Arrays ---"
var names[3] : String
names[0] = "Annmarie"
names[1] = "Roland"
names[2] = "Kathrin"
print names[0]
print names[1]
print names[2]
print ""

// ─────────────────────────────────────────────
// Section 18: Functions — basic
// ─────────────────────────────────────────────
print "--- Section 18: Functions basic ---"
print double(6)
print square(5)
print add(3, 4)
print ""

// ─────────────────────────────────────────────
// Section 19: Functions — string return
// ─────────────────────────────────────────────
print "--- Section 19: Functions string return ---"
print greet("pBasic")
print shout("hello")
print ""

// ─────────────────────────────────────────────
// Section 20: Recursion
// ─────────────────────────────────────────────
print "--- Section 20: Recursion ---"
print factorial(5)
print factorial(10)
print fib(7)
print fib(11)
print ""

// ─────────────────────────────────────────────
// Section 21: Local Scope
// ─────────────────────────────────────────────
print "--- Section 21: Local Scope ---"
var gscope : Int = 100
print scopeTest(555)
print gscope
print ""

// ─────────────────────────────────────────────
// Section 22: Functions in expressions
// ─────────────────────────────────────────────
print "--- Section 22: Functions in expressions ---"
print double(3) + square(2)
print add(double(2), square(3))
print ""

// ─────────────────────────────────────────────
// Section 23: Functions in control flow
// ─────────────────────────────────────────────
print "--- Section 23: Functions in control flow ---"
var fctotal : Int = 0
for fi = 1 to 5
    fctotal = fctotal + double(fi)
next fi
print fctotal
var fw : Int = 1
var fwsum : Int = 0
while (fw <= 4) {
    fwsum = fwsum + square(fw)
    fw = fw + 1
}
print fwsum
print ""

// ─────────────────────────────────────────────
// Section 24: TAB
// ─────────────────────────────────────────────
print "--- Section 24: TAB ---"
print "A";
TAB(5)
print "B";
TAB(5)
print "C"
print ""

// ─────────────────────────────────────────────
// Section 25: PRINT formatting
// ─────────────────────────────────────────────
print "--- Section 25: PRINT formatting ---"
print "no newline ";
print "same line"
print "Value: ";
print 42
print ""

// ─────────────────────────────────────────────
// Section 26: RND
// ─────────────────────────────────────────────
print "--- Section 26: RND ---"
var r1 : Float = RND(0)
var r2 : Float = RND(0)
// Just verify they are in range 0-1 (not equal is not guaranteed but almost certain)
if r1 >= 0 then print "RND in range"
if r1 <= 1 then print "RND bounded"
print ""

// ─────────────────────────────────────────────
// Section 27: CLS
// ─────────────────────────────────────────────
print "--- Section 27: CLS ---"
print "CLS test (screen will clear briefly)"
CLS
print "CLS executed"
print ""

// ─────────────────────────────────────────────
// Section 28: LOCATE
// ─────────────────────────────────────────────
print "--- Section 28: LOCATE ---"
LOCATE 12, 30
print "LOCATE test"
LOCATE 13, 1
print "🖤"

// ─────────────────────────────────────────────
// Section 29: TIMER
// ─────────────────────────────────────────────
print "--- Section 29: TIMER ---"
var ticks : Int = 0
TIMER 0.1 tickFunc
TIMERON
var tw : Int = 0
while (tw < 5000) {
    tw = tw + 1
}
TIMEROFF
print ticks
print ""

// ─────────────────────────────────────────────
// Section 30: INKEY$ (non-blocking — returns empty in non-interactive)
// ─────────────────────────────────────────────
print "--- Section 30: INKEY$ ---"
var k$ : String = INKEY$
print "INKEY$ returned (empty expected in batch): '";
print k$;
print "'"
print ""

// ─────────────────────────────────────────────
// Section 31: Sine Wave Visualizer
// ─────────────────────────────────────────────
print "--- Section 31: Sine Wave Visualizer ---"
print ""
var freq : Float = 0.3
var amp : Float = 10.0
var offset : Float = 15.0
var value : Float = 0.0
var spaces : Int = 0
for n = 0 to 20
    value = SIN(n * freq) * amp + offset
    TAB(value)
    print "*"
next n
print ""
print "Wave complete!"
print ""

// ─────────────────────────────────────────────
// Section 32: Multi-Dimensional Arrays
// ─────────────────────────────────────────────
print "--- Section 32: Multi-Dim Arrays ---"
var myArray[200,3] : Float
var fzed : Float = 3.7
myArray[37,2] = fzed
var fZoo : Float = myArray[37,2] * 2.3
print fZoo
// expected: 8.51

var grid[4,4] : Int
grid[0,0] = 1
grid[1,1] = 5
grid[2,2] = 9
grid[3,3] = 16
print grid[0,0]    // 1
print grid[1,1]    // 5
print grid[2,2]    // 9
print grid[3,3]    // 16

var names2[3,2] : String
names2[0,0] = "Ann Marie"
names2[1,0] = "Kathrin"
names2[2,0] = "John"
print names2[0,0]
print names2[1,0]
print names2[2,0]
print ""


// ─────────────────────────────────────────────
// Section 33: Logical AND / OR / XOR / NOT
// ─────────────────────────────────────────────
print "--- Section 33: AND OR XOR NOT ---"
var p : Int = 6
var q : Int = 3
var z : Int = 0

// Logical (non-integer operands via comparison results)
if p > 0 && q > 0 then print "AND true"
if p > 0 && z > 0 then print "ERROR: AND should be false"
if p > 0 || z > 0 then print "OR true"
if z > 0 || z > 0 then print "ERROR: OR should be false"
if p > 0 ^^ z > 0 then print "XOR true"
if p > 0 ^^ q > 0 then print "ERROR: XOR should be false"

// Bitwise (integer operands)
var band : Int = 6 && 3
var bor  : Int = 6 || 3
var bxor : Int = 6 ^^ 3
print band
print bor
print bxor

// NOT
var t : Int = 1
var f2 : Int = 0
print !t
print !f2
var bnot : Int = !6
print bnot
print ""


// ─────────────────────────────────────────────
// Section 34: VAL() CHR$() ASC()
// ─────────────────────────────────────────────
print "--- Section 34: VAL() CHR$() ASC() ---"
print VAL("3.14")          // 3.14
print VAL("  42  ")        // 42
print VAL("12abc")         // 12
print VAL("abc")           // 0
print CHR$(65)             // A
print CHR$(66)             // B
print CHR$(32)             // (space)
print CHR$(128512)         // 😀
print ASC("A")             // 65
print ASC("B")             // 66
print ASC("😀")            // 128512
var s$ : String = "Hello"
print VAL("99") + 1        // 100
print CHR$(ASC("A") + 1)   // B  (round-trip test)
print asc("🐐")
print chr$(128016)
print ""
print "ASCII [33-127]: "
for n = 33 to 90
print chr$(n); 
next n
print ""
for n = 91 to 127 
print chr$(n);
next n
print "" 
print ""

// ─────────────────────────────────────────────
// Section 35: SOUND command
// ─────────────────────────────────────────────
print "--- Section 35: SOUND() Command ---"
var rSnd = 60
print "You should hear MIDI " + STR$(rSnd) + " + " + STR$(rSnd+5)
print "SOUND(60, 0.5, 0.25)"
print "SOUND(65, 0.5, 0.25)"
SOUND(rSnd, 0.5, 0.25)
SOUND(rSnd+5, 0.5, 0.25)
SAY "The time is: " + TIME
print ""
print ""

// ─────────────────────────────────────────────
// Section 36: TEXT() and FILL() Text Colour
// ─────────────────────────────────────────────
print "--- Section 36: TEXT() and FILL() Colours ---"

// dark green background
TEXT(1, 0, 0, 1)
fill(0, 0.3, 0, 1)
for z = 1 to 4
print "red on green  ";
next z
print

// dark red background
FILL(0.5, 0, 0, 1)
for z = 1 to 4
print "red on red  ";
next z
print

// black background fill
fill(0, 0, 0, 1)
for z = 1 to 4
print "red on black  ";
next z
print

// transparent background fill (default)
fill(0,0,0,0)
for z = 1 to 4
print "red in space  ";
next z
print

// dark green background
TEXT(0, 0.91, 0.23, 1)
fill(0, 0.3, 0, 1)
for z = 1 to 4
print "hello on green  ";
next z
print

// dark red background
FILL(0.5, 0, 0, 1)
for z = 1 to 4
print "green on red  ";
next z
print

// black background fill
TEXT(0,0,1,1)
fill(0, 0, 0, 1)
for z = 1 to 4
print "blue on black  ";
next z
print

// restore transparent default
fill(0,0,0,0)
for z = 1 to 4
print "blue in space  ";
next z
print

// back to phosphor green text
TEXT(0, 0.91, 0.23, 1)
fill(0,0,0,0)
for z = 1 to 4
print "green in space  ";
next z
print ""
print ""


// ─────────────────────────────────────────────
// Section 37: MOD % Operator
// ─────────────────────────────────────────────
print "--- Section 37: MOD % Operator ---"

var a : Int = 10
var b : Int = 3
var r : Int = 0

r = a % b
print "10 % 3 = " + STR$(r)         // expect: 1
r = 10 % 5
print "10 % 5 = " + STR$(r)         // expect: 0
r = 7 % 7
print "7 % 7 = " + STR$(r)          // expect: 0
r = 1 % 7
print "1 % 7 = " + STR$(r)          // expect: 1
var c : Float = 0.0
c = 10.5 % 3.0
print "10.5 % 3.0 = " + STR$(c)     // expect: 1.5
c = -7.0 % 3.0
print "-7.0 % 3.0 = " + STR$(c)     // expect: -1.0

// MOD in a FOR loop — print even numbers 0-10
print "Even numbers 0-10:"
var n : Int = 0
for n = 0 to 10
    if n % 2 == 0 then print n;
next n
print ""

// MOD to wrap a value — clock hand cycling 0..11
print "Clock wrap 0-11:"
var h : Int = 0
for h = 0 to 14
    var w : Int = h % 12
    print w;
next h
print ""
print ""


// ───────────────────────────────────────────────
// Section 38: Native DIST() vs SQRT(dx*dx + dy*dy)
// ───────────────────────────────────────────────
print "--- Section 38: Native DIST() vs SQRT(dx*dx + dy*dy) ---"
print ""
var startTime$ : String = TIME
print "• Native DIST() Start: " + startTime$

var x1 : Float = 0.0
var y1 : Float = 0.0
var x2 : Float = 0.0
var y2 : Float = 0.0
var d  : Float = 0.0
var accum : Float = 0.0
var i  : Int = 0

for i = 0 to 999
    x1 = i * 0.5
    y1 = i * 0.3
    x2 = i * 1.2
    y2 = i * 0.7
    d = DIST(x1, y1, x2, y2)
    accum = accum + d
next i

// Calculate Elaspsed Seconds for Native DIST()
var endTime$ : String = TIME
var startSec   : Float = timeToSeconds(startTime$)
var endSec     : Float = timeToSeconds(endTime$)
var elapsed    : Float = endSec - startSec
if elapsed < 0 then elapsed = elapsed + 86400.0

print "• Native DIST() End:   " + endTime$
print "• Elapsed Seconds:     " + STR$(elapsed)
print "  Accum: " + STR$(accum)
print ""


var startTime2$ : String = TIME
print "• Interpreted pDist Start: " + startTime2$

var x1b : Float = 0.0
var y1b : Float = 0.0
var x2b : Float = 0.0
var y2b : Float = 0.0
var db  : Float = 0.0
var accumB : Float = 0.0
var j  : Int = 0

for j = 0 to 999
    x1b = j * 0.5
    y1b = j * 0.3
    x2b = j * 1.2
    y2b = j * 0.7
    db = pDist(x1b, y1b, x2b, y2b)
    accumB = accumB + db
next j

// Calculate Elaspsed Seconds for Interpreted DIST()
var endTime2$ : String = TIME
var startSec2   : Float = timeToSeconds(startTime2$)
var endSec2     : Float = timeToSeconds(endTime2$)
var elapsed2    : Float = endSec2 - startSec2
if elapsed2 < 0 then elapsed2 = elapsed2 + 86400.0

print "• Interpreted pDist End:   " + endTime2$
print "• Elapsed Seconds:     " + STR$(elapsed2)
print "  Accum: " + STR$(accumB)
print ""
print ""


// ───────────────────────────────────────────────
// Sections 39: Multi-Line IF {} Nesting
// ───────────────────────────────────────────────
print "--- Sections 39: Multi-Line IF {} Nesting ---"
print ""
print "• Deeply nested IF + WHILE: "
var total : Int = 0
var p : Int = 1
while (p <= 3) {
    if (p == 1) {
        total = total + 100
    }
    if (p == 2) {
        var q : Int = 0
        while (q < 3) {
            total = total + 10
            q = q + 1
        }
    }
    if (p == 3) {
        total = total + 1
    }
    p = p + 1
}
print "  PASS: total = " + STR$(total) + " (expected 131)"
if (total <> 131) {
    print "  FAIL: expected 131, got " + STR$(total)
}
print ""

print "• Multi-line IF within Function: "
print classify(15)
print classify(7)
print classify(2)
print ""


// Milestone 39b: BREAK Test
// BREAK will exit the innermost WHILE or IF block. 

// BREAK out of WHILE
var i : Int = 0
while (i < 100) {
    if (i == 5) {
        break
    }
    i = i + 1
}
print "• WHILE BREAK: i = " + STR$(i)    // expect: 5

// BREAK out of IF block
var x : Int = 0
if (1 == 1) {
    x = 10
    break
    x = 99
}
print "• IF BREAK: x = " + STR$(x)       // expect: 10

// Nested — BREAK exits only innermost
var j : Int = 0
var outer : Int = 0
while (outer < 3) {
    j = 0
    while (j < 100) {
        if (j == 4) {
            break
        }
        j = j + 1
    }
    outer = outer + 1
}
print "• Nested BREAK: j = " + STR$(j)        // expect: 4
print "• Nested BREAK: outer = " + STR$(outer) // expect: 3
print ""
print ""


// ───────────────────────────────────────────────
// Sections 42-45: STRING$ INSTR SORT() SORTLEN()
// ───────────────────────────────────────────────
print "--- Sections 42-45: STRING$ INSTR SORT() ----- "
print ""
var aaa$ : String = STRING$(23,"- ")
var bbb$ : String = STRING$(12, "abc ")
var ccc$ : String = STRING$(0, "x")
var ddd$ : String = STRING$(1025, "x")
print "print string$(23,- ):    "; 
print aaa$
print "print string$(12,abc ):  "; 
print bbb$
print "LEN of string$(0, x):    " + STR$(LEN(ccc$))
print "LEN of string$(1025, x): " + STR$(LEN(ddd$))
print ""
print ""


// ───────────────────────────────────────────────
// Section 58: Functions with Multi-Dimensional Arrays
// ───────────────────────────────────────────────
print "--- Section 58: Functions with Array[] Parameters ----- "
print ""

var testArr[5] : Int
print "calling func fillArray(arr[], n)"
fillArray(testArr[], 5)
print testArr[0]   // 0
print testArr[4]   // 8

var gridTest[3,3] : Int
print "calling func fillGrid(grid[], rows, cols)"
fillGrid(gridTest[], 3, 3)
print gridTest[0,0]   // 0
print gridTest[1,1]   // 4
print gridTest[2,2]   // 8

func fillArray(arr[], n) {
    for i = 0 to n-1
        arr[i] = i * 2
    next i
    return arr[]
}

func fillGrid(grid[], rows, cols) {
    for r = 0 to rows-1
        for c = 0 to cols-1
            grid[r,c] = r * cols + c
        next c
    next r
    return grid[]
}

print ""
print ""


// ───────────────────────────────────────────────
// Milestones 51-54 • CLONE() SPRITE() STAMP()
// ───────────────────────────────────────────────
print "--- Milestones 51-54 • CLONE() SPRITE() STAMP() ----- "

// ── Draw Hypotrochoid ───────────────────────────────-----
var cx : Float = 1100.0
var cy : Float = 124.0
var R  : Float = 24.0
var r  : Float = 9.0
var d  : Float = 24.0
var t  : Float = 0.0
var x  : Float = 0.0
var y  : Float = 0.0
var Angular : Float = 0

PEN 3
TEXT(0, 0.91, 0.23, 1)
for t = 0 to 240 step 0.5
    x = (R - r) * COS(t) + d * COS((R - r) * t / r) + cx
    y = (R - r) * SIN(t) - d * SIN((R - r) * t / r) + cy
    POINT(x, y, 0, 0.91, 0.23, 1.0)
next t


// ── Clone the Graphic Canvas into Sprite 5 ───────────────
PEN 1
TEXT(1.0, 0.1, 0.0, 1)
//ROUNDRECT(1056, 80, 1144, 168, 20)
CLONE(5, 1059, 83, 1143, 167)
//STAMP(1101.0,470.0,5)

SPRITE(1, 750.0, 220.0, 22.5, 0.8, 1, 1.0, "Demos/viperOn.png")
STAMP(850,220,1)
SPRITE(1, , 42, 45.0, 0.6, , , )
STAMP(950,220,1)

// revert sprite to scale:0 rotation:0
SPRITE(1, 750.0, 220.0, 0, 1.0, 1, 1.0, )

TEXT(0, 0.91, 0.23, 1)
PRINT "Hit ESC to Continue. "

TIMER 0.04 spinSprite
TIMERON

while (INKEY$ <> "ESC") {
}

TIMEROFF
cls
print "Milestones 51-54 • CLONE() SPRITE() STAMP()     ✅  Complete "
print " "
SPRITE(5, , , , , 0, , )


print "============================================"
fill(0, 0.3, 0, 0.7)
print "  pBasic v0.8.58 Validation Complete        "
fill(0, 0, 0, 0)
print "============================================"

meow
end


// ─────────────────────────────────────────────
// Function definitions
// ─────────────────────────────────────────────

func spinSprite() {
	//SPRITE(5, 1101, 240, Angular, 1.0, 1, 1.0, )
	var radians : Float = Angular * PI / 180.0
	var amplitude : Float = 0.35
	var midpoint : Float = 0.65
	var aleph : Float = midpoint + amplitude * SIN(radians)
	SPRITE(5, 1101, 240, Angular, 1.0, 1, aleph, )
	Angular = Angular + 5
}

func sayHello() {
    print "Hello from sayHello"
    return 0
}

func double(n) {
    return n * 2
}

func square(n) {
    return n * n
}

func add(a, b) {
    return a + b
}

func greet(name$) {
    var result$ : String = "Hello, "
    result$ = result$ + name$
    return result$
}

func shout(s$) {
    var upper$ : String = ""
    var slen : Int = 0
    slen = LEN(s$)
    var si : Int = 0
    while (si < slen) {
        upper$ = upper$ + MID$(s$, si, 1)
        si = si + 1
    }
    upper$ = upper$ + "!!!"
    return upper$
}

func factorial(n) {
    if n <= 1 then return 1
    return n * factorial(n - 1)
}

func fib(n) {
    if n <= 0 then return 0
    if n == 1 then return 1
    return fib(n - 1) + fib(n - 2)
}

func scopeTest(val) {
    var gscope : Int = 0
    gscope = val
    return gscope
}

func tickFunc() {
    ticks = ticks + 1
    return 0
}

// pDist() — interpreted equivalent of DIST()
// uses SQRT(dx*dx + dy*dy)
func pDist(x1, y1, x2, y2) {
    var dx : Float = x2 - x1
    var dy : Float = y2 - y1
    return SQRT(dx * dx + dy * dy)
}

// multi-line IF {} testing calls classify()
func classify(n) {
    var result$ : String = ""
    if (n > 10) {
        result$ = "  big: " + STR$(n)
    }
    if (n > 4) {
        if (n <= 10) {
            result$ = "  medium: " + STR$(n)
        }
    }
    if (n <= 4) {
        result$ = "  small: " + STR$(n)
    }
    return result$
}

// =================================================
// Time string "HH:mm:ss" → seconds since midnight
// =================================================
func timeToSeconds(t$) {
    var h : Float = VAL(MID$(t$, 0, 2))
    var m : Float = VAL(MID$(t$, 3, 2))
    var s : Float = VAL(MID$(t$, 6, 2))
    return h*3600.0 + m*60.0 + s
}
