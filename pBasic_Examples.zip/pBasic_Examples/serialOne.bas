// serialTest.bas
cls
print "Serial RS-232 Test"
term on
print "Connected. Type on TRS-80 to receive. Type q to quit."
print ""
var a$ : String = ""
var running : Bool = 1
while (running == 1) {
    serialin a$
    print "RX: " + a$ + " doubled: " + str$(val(a$)*2)
    if a$ == "q" then running = 0
    if running == 1 {
        serialout "Echo: " + a$ + " doubled: " + str$(val(a$)*2)
    }
}
print "Done."
term off
end
