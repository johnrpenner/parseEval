// spirofour.bas • draws coloured Hypotrochoids
// pBASIC Demo by John Roland Penner ©2026

cls
clr

// Hypotrochoids variables
var cx : Float = 630.0
var cy : Float = 500.0
var R  : Float = 200.0
var r  : Float = 75.0
var d  : Float = 120.0
var t  : Float = 0.0
var x  : Float = 0.0
var y  : Float = 0.0


// HSB globals
var hsbH   : Float = 0.0
var hsbV   : Float = 0.0
var hsbRR  : Float = 0.0
var hsbGG  : Float = 0.0
var hsbBB  : Float = 0.0
var hsbSector : Float = 0.0
var hsbF   : Float = 0.0
var hsbQ   : Float = 0.0
var hsbT   : Float = 0.0

// HSB Cycling Index: n
var n : Int = 0

// This Should Run for about 48 Hours
for n1 = 0 to 2048
	//clr
	for n2 = 0 to 10
		
		locate 1,65
		fill(0,0.2,0,0.5)
		print "n1: "; 
		print n1; 
		print " n2: ";
		print n2;
		print "  ";
		
	    R = rnd(1) * 300 + 150
	    locate 2,65
	    print "R: "; 
	    print R; 
	    spiro()
		
	    r = rnd(1) * 300 + 20 
	    locate 2,65
	    print "r: ";
	    print r; 
	    spiro()
	
	    d = rnd(1) * 300 + 110
	    locate 2,65
	    print "d: "; 
	    print d; 
	    spiro()
	    
	    t = rnd(1) * 300 + 10
	    locate 2,65
	    print "t: ";
	    print t; 
		print "   ";
		fill(0,0,0,0)
	    spiro()
	    
	next n2
	
	// fresh canvas every 20 cycles
	if (n1 % 20 == 19) then CLR
	
next n1
meow
end

func spiro() {
	
	// HSB Colour cycling: hue based on index n (0–360)
	hsbH = n                            // HUE
	//hsbV = 1.0 - (RND(1) * 0.95)        // Brightness
	hsbV = (RND(1) * 0.9) + 0.1           // Brightness
	calcHSB()
		
	// Cycle HSB Space through 360°
	n = n + (rnd(0) * 18 + 12)
	if rnd(0) > 0.618 then n = n + 180
	if rnd(0) > 0.9 then n = rnd(0)*360
	if n > 360 then n = n - 360
	
	// Assign HSB Colours to Pen
	var RR : Float = hsbRR
	var GG : Float = hsbGG
	var BB : Float = hsbBB
	
	// Randomise Brush Size and Steps 
    var pRnd : Float = RND(1) * 18.0 + 1
    var Steps : Float = RND(1) * 512 + 500
	
	// Colour Dimming every second pass
	if int(n2/2) <> (n2/2) {
		RR = RR/12
		GG = GG/12
		BB = BB/12
		pRnd = RND(1) * 24.0 + 4
	}
	
	// CLR with black circles
    if n2 == 0 {
    	RR = 0.05
    	GG = 0.05
    	BB = 0.05
    	pRnd = 28.0
    	Steps = 1024
    }    
	
    PEN pRnd
    
    // Main Draw Loop
    FOR t = 0 TO Steps STEP 0.75
        x = (R - r) * COS(t) + d * COS((R - r) * t / r) + cx
        y = (R - r) * SIN(t) - d * SIN((R - r) * t / r) + cy
        var AA : Float = 1.0 - (RND(1) * 0.75)
        point(x,y, RR, GG, BB, AA)
    NEXT t
	
	var k$ = INKEY$
	if (k$ == "ESC") {
		fill(0,0,0,0)
		print " "
		print "farewell soul journer ✨ "	
		MEOW
		END
	}
	
    RETURN 0
}


// ===================================================================
// HSB → RGB conversion (extracted & adapted from lissajous3D.bas)
// Saturation fixed at 1.0, Value = hsbV (0.0–1.0)
// Stores result in hsbRR, hsbGG, hsbBB
// ===================================================================
func calcHSB() {
    if hsbV <= 0.0 then setBlack()
    if hsbV <= 0.0 then return 0

    var hn : Float = hsbH / 60.0
    hsbSector = INT(hn)
    hsbF = hn - hsbSector
    hsbQ = hsbV * (1.0 - hsbF)
    hsbT = hsbV * hsbF

    if hsbSector == 0.0 then setSector0()
    if hsbSector == 1.0 then setSector1()
    if hsbSector == 2.0 then setSector2()
    if hsbSector == 3.0 then setSector3()
    if hsbSector == 4.0 then setSector4()
    if hsbSector == 5.0 then setSector5()

    return 0
}

func setBlack() {
    hsbRR = 0.0
    hsbGG = 0.0
    hsbBB = 0.0
    return 0
}

func setSector0() {
    hsbRR = hsbV
    hsbGG = hsbT
    hsbBB = 0.0
    return 0
}

func setSector1() {
    hsbRR = hsbQ
    hsbGG = hsbV
    hsbBB = 0.0
    return 0
}

func setSector2() {
    hsbRR = 0.0
    hsbGG = hsbV
    hsbBB = hsbT
    return 0
}

func setSector3() {
    hsbRR = 0.0
    hsbGG = hsbQ
    hsbBB = hsbV
    return 0
}

func setSector4() {
    hsbRR = hsbT
    hsbGG = 0.0
    hsbBB = hsbV
    return 0
}

func setSector5() {
    hsbRR = hsbV
    hsbGG = 0.0
    hsbBB = hsbQ
    return 0
}
