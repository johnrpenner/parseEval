// torus3D.bas

CLS
print "Torus 3D"

// ================================================
// 3D TORUS - pBasic v0.8.54
// ================================================

cls
clr
PEN 3.0

print "Inicjalizacja systemu..."

var CX : Int = 410
var CY : Int = 400
var T  : Float = 0.0

var RING_R : Int = 290
var TUBE_R : Int = 135
//var SEG_M  : Int = 24
//var SEG_N  : Int = 12
var SEG_M  : Int = 12
var SEG_N  : Int = 6

var IDX : Int = 0
var FC  : Int = 0

// Arrays
var VX[300] : Float
var VY[300] : Float
var VZ[300] : Float
var PX[300] : Float
var PY[300] : Float
var PZ[300] : Float
var FZ[300] : Float
var FI[300] : Int
var FJ[300] : Int

// ─────────────────────────────────────────────
// Initialize
// ─────────────────────────────────────────────
func initArrays() {
    IDX = 0
    FC = 0
    return 0
}

func generateTorus() {
    var i : Int = 0
    var j : Int = 0
    var idx : Int = 0
    var phi : Float = 0.0
    var theta : Float = 0.0
    var rr : Float = 0.0
    
    for i = 0 to SEG_M-1
        phi = i * 6.283 / SEG_M
        for j = 0 to SEG_N-1
            theta = j * 6.283 / SEG_N
            rr = RING_R + TUBE_R * COS(theta)
            VX[idx] = rr * COS(phi)
            VY[idx] = TUBE_R * SIN(theta)
            VZ[idx] = rr * SIN(phi)
            idx = idx + 1
        next j
    next i
    
    IDX = idx
    return 0
}

// ─────────────────────────────────────────────
// Main Animation Loop
// ─────────────────────────────────────────────
initArrays()
generateTorus()

var playing : Int = 1

while (playing == 1) {
    T = T + 0.02
    
    // Clear screen (black)
    //fill(0, 0, 0, 1)
    CLR
    
    calcOrbit()
    applyTransforms()
    collectAndCull()
    sortZBuffer()
    drawFaces()
    
    // SYNC equivalent - let pBasic refresh
    // (pBasic usually updates automatically)
}

end


// ================================================
// PROCEDURES
// ================================================

func calcOrbit() {
    // OX and OY are calculated every frame
    return 0
}

func applyTransforms() {
    var s1 : Float = SIN(T*1.5)
    var c1 : Float = COS(T*1.5)
    var s2 : Float = SIN(T*0.8)
    var c2 : Float = COS(T*0.8)
    var s3 : Float = SIN(T*0.5)
    var c3 : Float = COS(T*0.5)
    
    var i : Int = 0
    var x1 : Float = 0
    var y1 : Float = 0
    var z1 : Float = 0
    var z2 : Float = 0
    var x2 : Float = 0
	var y2 : Float = 0
    
    for i = 0 to IDX-1
        x1 = VX[i]*c1 - VZ[i]*s1
        z1 = VX[i]*s1 + VZ[i]*c1
        y1 = VY[i]*c2 - z1*s2
        z2 = VY[i]*s2 + z1*c2
        x2 = x1*c3 - y1*s3
        y2 = x1*s3 + y1*c3
        
        PX[i] = 410 + COS(T*1.2)*220 + x2
        PY[i] = 200 + SIN(T*1.2)*80  + y2
        PZ[i] = z2
    next i
    return 0
}

func collectAndCull() {
    var fc : Int = 0
    var i : Int = 0
    var j : Int = 0
    var i2 : Int = 0
    var j2 : Int = 0
    var p1 : Int = 0
    var p2 : Int = 0
    var p3 : Int = 0
    var p4 : Int = 0
    var v : Float = 0.0
    
    for i = 0 to SEG_M-1
        i2 = (i + 1) % SEG_M
        for j = 0 to SEG_N-1
            j2 = (j + 1) % SEG_N
            
            p1 = i * SEG_N + j
            p2 = i2 * SEG_N + j
            p3 = i2 * SEG_N + j2
            p4 = i * SEG_N + j2
            
            v = (PX[p2]-PX[p1])*(PY[p3]-PY[p1]) - (PY[p2]-PY[p1])*(PX[p3]-PX[p1])
            
            if (v > 0) {
                FZ[fc] = PZ[p1] + PZ[p2] + PZ[p3] + PZ[p4]
                FI[fc] = i
                FJ[fc] = j
                fc = fc + 1
            }
        next j
    next i
    FC = fc
    return 0
}

func sortZBuffer() {
    var k : Int = 0
    var l : Int = 0
    for k = 0 to FC-2
        for l = k+1 to FC-1
            if ( FZ[k] < FZ[l] ) {
                // SWAP
                var temp : Float = FZ[k]
                FZ[k] = FZ[l]
                FZ[l] = temp
                
                var tempi : Int = FI[k]
                FI[k] = FI[l]
                FI[l] = tempi
                
                var tempj : Int = FJ[k]
                FJ[k] = FJ[l]
                FJ[l] = tempj
            }
        next l
    next k
    return 0
}

func drawFaces() {
    var k : Int = 0
    var i : Int = 0
    var j : Int = 0
    var i2 : Int = 0
    var j2 : Int = 0
    var p1 : Int = 0
    var p2 : Int = 0
    var p3 : Int = 0
    var p4 : Int = 0
    var pl : Float = 0.0
    var r : Float = 0.0
    var g : Float = 0.0
    var b : Float = 0.0
    
    for k = 0 to FC-1
        i = FI[k]
        j = FJ[k]
        i2 = (i + 1) % SEG_M
        j2 = (j + 1) % SEG_N
        
        p1 = i * SEG_N + j
        p2 = i2 * SEG_N + j
        p3 = i2 * SEG_N + j2
        p4 = i * SEG_N + j2
        
        pl = (SIN(i/2.0 + T*4) + COS(j/2.0 + T*3) + 2.0) / 4.0
        
        r = int(100 + 155 * SIN(T + i/4.0) * pl)
        g = int(100 + 155 * COS(T*1.2 + j/3.0) * pl)
        b = int(255 * pl)
        
        // Draw two triangles for each quad
        TRI(PX[p1], PY[p1], PX[p2], PY[p2], PX[p3], PY[p3], r, g, b)
        TRI(PX[p1], PY[p1], PX[p3], PY[p3], PX[p4], PY[p4], r, g, b)
    next k
    return 0
}

// TRI Function Didnt Exist, So We Wrote Make One! 
func TRI(x1, y1, x2, y2, x3, y3, r, g, b) {
    var midX : Float = (x1 + x2 + x3) / 3.0
    var midY : Float = (y1 + y2 + y3) / 3.0
    
    BUFFER
    
    // Draw outline
    LINE(x1, y1, x2, y2, r, g, b, 1.0)
    LINE(x2, y2, x3, y3, r, g, b, 1.0)
    LINE(x3, y3, x1, y1, r, g, b, 1.0)
    
    // Safer flood fill with small offset to avoid edges
    FLOOD(midX + 1.5, midY + 1.5, r, g, b, 0.85)
    
    BUFFER
    
    return 0
}
