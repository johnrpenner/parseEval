// entire multi-line file
var modelFile$ : String = "Demos/elite-mamba.txt"
var result$[150] : String

var bb[150] : String
var cc[150] : String

bb[] = LOAD(modelFile$)
var lineCount = LEN(bb[])
print "lineCount: " + str$(lineCount)

var wordCount : Int = 0

for z = 0 to lineCount-1
	print bb[z]
	wordCount = getWords(bb[z])
	print "wordCount: " + str$(wordCount)
	for z2 = 0 to wordCount
		print "• " + str$(z2) + " " + result$[z2]
	next z2
	print " "
next z

// single string
var abc$ : String = "sphinx of black quartz judge my vow"
wordCount = getWords(abc$)
print "wordCount: " + str$(wordCount)
for z2 = 0 to wordCount
	print "• " + str$(z2) + " " + result$[z2]
next z2

end


// ================================================
// Split string into words (space separated)
// returns result$[count] -- must declane globally
// ================================================
func getWords(a$) {
	//var result$[150] : String
    var lineLen : Int = LEN(a$)
    var index : Int = 0
    var start : Int = 0
    var count : Int = 0
    var inWord : Int = 0
    var ch$ : String = MID$(a$, index, 1)
    
    while (index <= lineLen) {
        ch$ = MID$(a$, index, 1)
        
        if (ch$ <> " " && ch$ <> "" && inWord == 0) {
            start = index
            inWord = 1
        }
        
        if ((ch$ == " " || index == lineLen) && inWord == 1) {
            result$[count] = MID$(a$, start, index - start)
            count = count + 1
            inWord = 0
        }
        
        index = index + 1
    }
    
    return count-1
}
