// Hunt the Wumpus for pBasic v0.8.54
// adventure game created by Gregory Yob
// published in Creative Computing in 1975
// Ported to pBasic by John Roland Penner
// May 4, 2026

clr
cls

// ─────────────────────────────────────────────
// Cave Connections
// ─────────────────────────────────────────────
var cave[21,3] : Int

cave[1,0] = 2
cave[1,1] = 3
cave[1,2] = 4
cave[2,0] = 1
cave[2,1] = 5
cave[2,2] = 6
cave[3,0] = 1
cave[3,1] = 7
cave[3,2] = 8
cave[4,0] = 1
cave[4,1] = 9
cave[4,2] = 10
cave[5,0] = 2
cave[5,1] = 9
cave[5,2] = 11
cave[6,0] = 2
cave[6,1] = 7
cave[6,2] = 12
cave[7,0] = 3
cave[7,1] = 6
cave[7,2] = 13
cave[8,0] = 3
cave[8,1] = 10
cave[8,2] = 14
cave[9,0] = 4
cave[9,1] = 5
cave[9,2] = 15
cave[10,0] = 4
cave[10,1] = 8
cave[10,2] = 16
cave[11,0] = 5
cave[11,1] = 12
cave[11,2] = 17
cave[12,0] = 6
cave[12,1] = 11
cave[12,2] = 18
cave[13,0] = 7
cave[13,1] = 14
cave[13,2] = 18
cave[14,0] = 8
cave[14,1] = 13
cave[14,2] = 19
cave[15,0] = 9
cave[15,1] = 16
cave[15,2] = 17
cave[16,0] = 10
cave[16,1] = 15
cave[16,2] = 19
cave[17,0] = 11
cave[17,1] = 20
cave[17,2] = 15
cave[18,0] = 12
cave[18,1] = 13
cave[18,2] = 20
cave[19,0] = 14
cave[19,1] = 16
cave[19,2] = 20
cave[20,0] = 17
cave[20,1] = 18
cave[20,2] = 19

// ─────────────────────────────────────────────
// Variables
// ─────────────────────────────────────────────
var player : Int = 1
var wumpus : Int = 0
var bat1 : Int = 0
var bat2 : Int = 0
var pit1 : Int = 0
var pit2 : Int = 0
var arrows : Int = 5
var room : Int = 0
var choice$ : String = ""
var act$ : String = ""
var playing : Int = 1


// ─────────────────────────────────────────────
// Initialize Game
// ─────────────────────────────────────────────
func initGame() {
    player = 1
    arrows = 5
    playing = 1
    
    wumpus = int(rnd(0)*19) + 2
    
    bat1 = int(rnd(0)*19) + 2
    
    bat2 = int(rnd(0)*19) + 2
    while (bat2 == bat1 || bat2 == wumpus) {
        bat2 = int(rnd(0)*19) + 2
    }
    
    pit1 = int(rnd(0)*19) + 2
    while (pit1 == bat1 || pit1 == bat2 || pit1 == wumpus) {
        pit1 = int(rnd(0)*19) + 2
    }
    
    pit2 = int(rnd(0)*19) + 2
    while (pit2 == bat1 || pit2 == bat2 || pit2 == pit1 || pit2 == wumpus) {
        pit2 = int(rnd(0)*19) + 2
    }
    
    // Uncomment Next Line for Cheat (reveals Wumpus and Bat Locations)
    //print "Game Initialized [ 👹 " + str$(wumpus) + " 🦇 " + str$(bat1) + " 🦇 " + str$(bat2) + " ]"
    
    return 0
}


// ─────────────────────────────────────────────
// Main Game
// ─────────────────────────────────────────────

print "==================="
fill(0, 0.3, 0, 0.7)
print "  Hunt the Wumpus  "
fill(0, 0, 0, 0)
print "==================="
screenCatcher()

initGame()

//-----------------------------------------------| player Session • WHILE:1 |----- 
while (playing == 1) {
	print " "
    print "You are in Room " + numToAlpha(player) + " with " + STR$(arrows) + " arrow" + plural(arrows) + " left. "
    
    var adj0 = cave[player,0]
    var adj1 = cave[player,1]
    var adj2 = cave[player,2]
    
    // PRINT STATUS
    print "Adjacent rooms: " + roomsToLetters(adj0, adj1, adj2)
    sense(adj0, adj1, adj2)
    print ""
    printMap()
    
    //---------------------------------------------| Choose Room • WHILE:2 |----- 
    
    var choice$ = ""
    var validRm = 0
    
    while (validRm == 0) {
	    INPUT "Choose an Adjacent Room (A-T or number): "; choice$ 
	    choice$ = upper(choice$)
	    room = alphaToNum(choice$)
	    if room == 0 then room = val(choice$)
	    if ( room < 1 || room > 20 ) then print "Invalid room (" + STR$(room) + ", try again. "
	    if ( room <> adj0 && room <> adj1 && room <> adj2 ) { 
	    		print "Not an Adjacent room. " 
	    		print "Adjacent rooms are: " + roomsToLetters(adj0, adj1, adj2)
	    		}
	    if ( room == adj0 || room == adj1 || room == adj2 ) then validRm = 1
    }
	
	
    //--------------------------------------------| player Action • WHILE:3 |-----
    
    var act$ = ""
	var validAct = 0
    
    while (validAct == 0) { 
    	INPUT "Walk or Shoot (W or S)? "; act$
    	act$ = upper(act$)
    	if ( act$ <> "W" && act$ <> "S" && act$ <> "X" ) then print "Enter W or S "
    	if ( act$ == "W" || act$ == "S" || act$ == "X") then validAct = 1
    }
        
    //--| WALK |------------ 
    
    if act$ == "W" {
        player = room
        
        if player == wumpus {
            print "The Wumpus Ate You! 👹  Game Over. "
            playing = 0
        }
        
        if (player == pit1 || player == pit2) {
            print "You Fall into a Bottomless Pit! 🕳️  Game Over. "
            playing = 0
        }
        
        if (player == bat1 || player == bat2) {
            print "A Super Bat Grabs You 🦇  and Flies You Elsewhere! "
            room = int(rnd(0)*19) + 2
            while (isEmpty(room) == 0) {
				room = int(rnd(0)*19) + 2
				}
			player = room
        }
    }
    
    
    //--| SHOOT |------------ 
    
    if act$ == "S" {
        
        // if player Shoots to wumpus room, player wins! 
        if (room == wumpus) {
            print "You Shot the Wumpus! 🎯  YOU WIN!! "
            playing = 0
        }
        
        if (room <> wumpus) {
        
            if (rnd(0) < 0.75) {
                var randTunnel = int(rnd(0)*3)
                wumpus = cave[wumpus, randTunnel]
                //print "debug | wumpus = " + str$(wumpus)
                
                if (wumpus == player) {
                    print "The Wumpus Woke Up and Ate you! 👹  Game Over."
                    playing = 0
                }
            }
        }
		
        arrows = arrows - 1
        if (arrows <= 0) {
            print "You ran out of Arrows! 🏹  Game Over. "
            playing = 0
        }
    }
    
}

print " "
print "==================="
fill(0, 0.3, 0, 0.7)
print "     GAME OVER     "
fill(0, 0, 0, 0)
print "==================="

end


// ─────────────────────────────────────────────
// Helper Functions
// ─────────────────────────────────────────────

func isEmpty(r) {
    var ret : Int = 1
    if (r == player || r == wumpus || r == bat1 || r == bat2 || r == pit1 || r == pit2) then ret = 0
    return ret
}

func screenCatcher() {
    for nn = 1 to 2048
    next nn
    return 0
}

func plural(n) {
    var ret$ : String = ""
    if n <> 1 then ret$ = "s"
    return ret$
}

func numToAlpha(n) {
    var ret$ : String = "?"
    if (n >= 1 && n <= 20) then ret$ = chr$(64 + n)
    return ret$
}

func alphaToNum(c$) {
    var ret : Int = 0
    //var ch$ : String = upper$(left$(c$,1))
    var ch$ : String = upper(c$)
    var code : Int = asc(ch$)
    if (code >= 65 && code <= 84) then ret = code - 64
    return ret
}

func roomsToLetters(r0, r1, r2) {
    var ret$ : String = ""
    ret$ = numToAlpha(r0) + ", " + numToAlpha(r1) + ", " + numToAlpha(r2)
    return ret$
}

func printMap() {
    print "     A...................B     "
    print "   ..  \               /  .    "
    print "   .     H-----I------J    .   "
    print "  ..    /      |       \   .   "
    print "  .    G _   . R- _     \   .  "
    print " ..   /    Q        -S---K  .  "
    print " .   /     \         /   \   . "
    print " . _-F_     \       /    _L_ . "
    print "E -    \_   /P-----T   _/   \ C"
    print " ..       O/        \M/    ... "
    print "   ...     \__    _ /   ...    "
    print "      ...     \ N/   ...       "
    print "         ...    | ...          "
    print "            ... D              "
    print ""
    return 0
}

func sense(adj0, adj1, adj2) {
    var bat = 0
    var pit = 0
    var a[3] : Int
    a[0] = adj0
    a[1] = adj1
    a[2] = adj2
    
    for i = 0 to 2
		if a[i] == wumpus then print "You smell something terrible nearby. "
		if (a[i] == bat1 || a[i] == bat2) then print "You hear a fluttering sound. "		
		if (a[i] == pit1 || a[i] == pit2) then print "You feel a cold draught from a nearby cavern. "
	next i
	return 0
}

func upper(caseStr$) {
	var result$ : String = ""
	var strLen : Int = 0
	var meep : String = ""
	var meepASC : Int = 32
	
	strLen = LEN(caseStr$)		
	for n = 0 to strLen {
		
		meep = MID$(caseStr$, n, 1)
		meepASC = ASC(meep)
		if meepASC > 96 && meepASC < 123 then meepASC = meepASC - 32
		result$ = result$ + CHR$(meepASC)
	}
	
	return result$
}
